import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { createWithReference } from "@/lib/case-ref";
import { saveFile } from "@/lib/uploads";
import { clientIp, rateLimit } from "@/lib/rate-limit";

export const runtime = "nodejs";

const CaseSchema = z.object({
  fullName: z.string().min(1).max(120),
  email: z.string().email().max(200),
  company: z.string().max(200).optional().or(z.literal("")),
  phone: z.string().max(40).optional().or(z.literal("")),
  country: z.string().min(1).max(120),
  url: z.string().max(500).optional().or(z.literal("")),
  platform: z.string().max(80).optional().or(z.literal("")),
  issueType: z.string().min(1),
  description: z.string().min(20).max(5000),
  relevantUrls: z.string().max(5000).optional().or(z.literal("")),
  // Consent must be affirmatively given — `false`/"false" is rejected.
  consent: z
    .union([z.string(), z.boolean()])
    .refine(
      (v) =>
        v === true ||
        (typeof v === "string" && ["true", "on", "yes", "1"].includes(v.toLowerCase())),
      { message: "Consent is required" }
    ),
});

const MAX_FILES = 6;
// 5 submissions per IP per 10 minutes.
const RATE_LIMIT = parseInt(process.env.CASES_RATE_LIMIT || "5", 10);
const RATE_WINDOW_MS = 10 * 60 * 1000;

export async function POST(req: NextRequest) {
  const ip = clientIp(req);
  const limit = rateLimit(`cases:${ip}`, RATE_LIMIT, RATE_WINDOW_MS);
  if (!limit.ok) {
    return NextResponse.json(
      { error: "Too many submissions. Please try again later." },
      { status: 429, headers: { "Retry-After": String(limit.retryAfter) } }
    );
  }

  try {
    const contentType = req.headers.get("content-type") || "";

    let data: Record<string, string | boolean> = {};
    let files: File[] = [];

    if (contentType.includes("multipart/form-data")) {
      const form = await req.formData();
      form.forEach((value, key) => {
        if (value instanceof File) {
          if (value.size > 0) files.push(value);
        } else {
          data[key] = String(value);
        }
      });
    } else if (contentType.includes("application/json")) {
      data = await req.json();
    } else {
      return NextResponse.json({ error: "Unsupported content type" }, { status: 415 });
    }

    const parsed = CaseSchema.safeParse(data);
    if (!parsed.success) {
      return NextResponse.json(
        { error: "Validation failed", issues: parsed.error.flatten() },
        { status: 400 }
      );
    }

    const newCase = await createWithReference((reference) =>
      prisma.case.create({
      data: {
        reference,
        fullName: parsed.data.fullName,
        email: parsed.data.email.toLowerCase().trim(),
        company: parsed.data.company || null,
        phone: parsed.data.phone || null,
        country: parsed.data.country,
        websiteUrl: parsed.data.url || null,
        platform: parsed.data.platform || null,
        issueType: parsed.data.issueType,
        description: parsed.data.description,
        relevantUrls: parsed.data.relevantUrls || null,
        status: "NEW",
      },
      })
    );

    // Save files
    let savedCount = 0;
    for (const file of files.slice(0, MAX_FILES)) {
      try {
        const saved = await saveFile(file);
        await prisma.caseFile.create({
          data: {
            caseId: newCase.id,
            filename: saved.filename,
            storedAs: saved.storedAs,
            mimeType: saved.mimeType,
            size: saved.size,
          },
        });
        savedCount++;
      } catch (e) {
        console.error("File save error:", e);
      }
    }

    await prisma.activity.create({
      data: {
        caseId: newCase.id,
        type: "CASE_CREATED",
        payload: JSON.stringify({ files: savedCount, source: "public_form" }),
      },
    });

    return NextResponse.json({
      ok: true,
      reference: newCase.reference,
      caseId: newCase.id,
      files: savedCount,
    });
  } catch (e) {
    console.error("Case create error:", e);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
