import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "./auth";

export async function getCurrentUser() {
  const session = await getServerSession(authOptions);
  return session?.user ?? null;
}

/**
 * Gate for admin-only pages.
 *
 * Checks BOTH that a session exists and that the user actually carries the
 * ADMIN role — a logged-in non-admin must never reach the dashboard.
 */
export async function requireAdmin() {
  const user = await getCurrentUser();
  if (!user) redirect("/admin/login");
  if (user.role !== "ADMIN") redirect("/admin/login?error=forbidden");
  return user;
}
