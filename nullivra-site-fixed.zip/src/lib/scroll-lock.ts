"use client";

import { useEffect } from "react";

/**
 * Reference-counted body scroll lock.
 *
 * Multiple overlays (mobile nav + enquiry modal) can be open at the same time.
 * Setting `document.body.style.overflow` directly from each of them caused a
 * glitch: closing one overlay unlocked scrolling while the other was still
 * open. This counter makes sure the page only unlocks when the last consumer
 * releases the lock.
 */
let locks = 0;
let previousOverflow = "";

export function lockScroll(): void {
  if (typeof document === "undefined") return;
  if (locks === 0) {
    previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
  }
  locks += 1;
}

export function unlockScroll(): void {
  if (typeof document === "undefined") return;
  if (locks === 0) return;
  locks -= 1;
  if (locks === 0) {
    document.body.style.overflow = previousOverflow;
    previousOverflow = "";
  }
}

/** Lock while `active` is true; automatically releases on unmount. */
export function useScrollLock(active: boolean): void {
  useEffect(() => {
    if (!active) return;
    lockScroll();
    return () => unlockScroll();
  }, [active]);
}
