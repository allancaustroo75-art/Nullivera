import { put, del } from "@vercel/blob";
import path from "path";
import crypto from "crypto";

// Files are stored in Vercel Blob (cloud object storage) instead of the
// local filesystem, since serverless hosting (Vercel/Netlify) has an
// ephemeral filesystem — anything written to disk can disappear on the
// next deploy or cold start.
//
// Requires BLOB_READ_WRITE_TOKEN in the environment. On Vercel, this is
// set automatically once you create a Blob store and connect it to the
// project (Storage tab in the dashboard). For local dev, run
// `vercel env pull` after creating the store, or set it manually in .env.
//
// SECURITY: Vercel Blob only serves objects over public URLs. The blob URL
// is therefore treated as a capability/secret: it is never exposed to the
// browser (downloads go through the admin-only /api/files/[id] proxy) and
// the key is randomised twice (UUID + random suffix) so it cannot be
// guessed or enumerated.

const MAX_BYTES = (parseInt(process.env.MAX_UPLOAD_MB || "10", 10)) * 1024 * 1024;

const ALLOWED_MIME = [
  "image/jpeg",
  "image/png",
  "image/webp",
  "image/gif",
  "application/pdf",
  "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
];

// Magic-byte signatures — the client-supplied MIME type is not trusted.
const SIGNATURES: Record<string, number[][]> = {
  "image/jpeg": [[0xff, 0xd8, 0xff]],
  "image/png": [[0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]],
  "image/gif": [
    [0x47, 0x49, 0x46, 0x38, 0x37, 0x61],
    [0x47, 0x49, 0x46, 0x38, 0x39, 0x61],
  ],
  // RIFF....WEBP — bytes 8..11 checked separately
  "image/webp": [[0x52, 0x49, 0x46, 0x46]],
  "application/pdf": [[0x25, 0x50, 0x44, 0x46]],
  // .doc (OLE compound file)
  "application/msword": [[0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1]],
  // .docx (ZIP container)
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document": [
    [0x50, 0x4b, 0x03, 0x04],
    [0x50, 0x4b, 0x05, 0x06],
    [0x50, 0x4b, 0x07, 0x08],
  ],
};

function startsWith(bytes: Uint8Array, sig: number[]): boolean {
  if (bytes.length < sig.length) return false;
  return sig.every((b, i) => bytes[i] === b);
}

function matchesSignature(mime: string, bytes: Uint8Array): boolean {
  const sigs = SIGNATURES[mime];
  if (!sigs) return false;
  const ok = sigs.some((sig) => startsWith(bytes, sig));
  if (!ok) return false;
  if (mime === "image/webp") {
    // "WEBP" at offset 8
    return (
      bytes.length >= 12 &&
      bytes[8] === 0x57 &&
      bytes[9] === 0x45 &&
      bytes[10] === 0x42 &&
      bytes[11] === 0x50
    );
  }
  return true;
}

export type SavedFile = {
  storedAs: string; // Blob URL — used to fetch/delete the file later
  filename: string;
  mimeType: string;
  size: number;
};

export async function saveFile(file: File): Promise<SavedFile> {
  if (file.size === 0) {
    throw new Error("Empty file");
  }
  if (file.size > MAX_BYTES) {
    throw new Error(`File too large. Max ${MAX_BYTES / 1024 / 1024}MB`);
  }
  if (!ALLOWED_MIME.includes(file.type)) {
    throw new Error(`File type not allowed: ${file.type}`);
  }

  // Verify the real content type from the file header, not the browser hint.
  const buffer = Buffer.from(await file.arrayBuffer());
  if (!matchesSignature(file.type, new Uint8Array(buffer.subarray(0, 16)))) {
    throw new Error("File content does not match its declared type");
  }

  const now = new Date();
  const subdir = `${now.getFullYear()}/${String(now.getMonth() + 1).padStart(2, "0")}`;
  const ext = path.extname(file.name).slice(0, 10) || "";
  const key = `${subdir}/${crypto.randomUUID()}${ext}`;

  const blob = await put(key, buffer, {
    access: "public",
    contentType: file.type,
    // Extra entropy so blob URLs cannot be guessed or enumerated.
    addRandomSuffix: true,
  });

  return {
    storedAs: blob.url,
    filename: file.name,
    mimeType: file.type,
    size: buffer.byteLength,
  };
}

export async function deleteFile(storedAs: string): Promise<void> {
  await del(storedAs);
}
