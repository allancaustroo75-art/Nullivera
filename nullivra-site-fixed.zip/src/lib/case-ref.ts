import { Prisma } from "@prisma/client";
import { prisma } from "./prisma";

/**
 * Next sequential reference for the current year, e.g. NV-2026-0001.
 *
 * NOTE: this read alone is not atomic — two concurrent submissions can read
 * the same "last" reference. Use `createWithReference` below, which retries
 * on the unique-constraint violation instead of returning a 500.
 */
export async function generateCaseReference(): Promise<string> {
  const year = new Date().getFullYear();
  const prefix = `NV-${year}-`;

  const lastCase = await prisma.case.findFirst({
    where: { reference: { startsWith: prefix } },
    orderBy: { reference: "desc" },
    select: { reference: true },
  });

  let nextNum = 1;
  if (lastCase) {
    const lastNum = parseInt(lastCase.reference.replace(prefix, ""), 10);
    if (!isNaN(lastNum)) nextNum = lastNum + 1;
  }

  return `${prefix}${String(nextNum).padStart(4, "0")}`;
}

function isUniqueViolation(e: unknown): boolean {
  return (
    e instanceof Prisma.PrismaClientKnownRequestError &&
    e.code === "P2002"
  );
}

/**
 * Creates a case, generating the reference and retrying if another request
 * grabbed the same number in the meantime. The database unique index on
 * `reference` is the source of truth, so duplicates are impossible.
 */
export async function createWithReference<T>(
  create: (reference: string) => Promise<T>,
  maxAttempts = 6
): Promise<T> {
  let lastError: unknown;
  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    const reference = await generateCaseReference();
    try {
      return await create(reference);
    } catch (e) {
      if (!isUniqueViolation(e)) throw e;
      lastError = e;
      // Small jittered backoff so racing requests don't collide again.
      await new Promise((r) => setTimeout(r, 25 + Math.random() * 75));
    }
  }
  throw lastError ?? new Error("Could not allocate a case reference");
}
