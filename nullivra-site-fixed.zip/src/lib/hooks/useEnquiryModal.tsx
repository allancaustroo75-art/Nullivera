"use client";

import { createContext, useContext, useState, useCallback, ReactNode } from "react";

type ModalMode = "case" | "consultation" | null;

type EnquiryModalContextType = {
  mode: ModalMode;
  open: (mode: Exclude<ModalMode, null>) => void;
  close: () => void;
};

const EnquiryModalContext = createContext<EnquiryModalContextType | null>(null);

export function EnquiryModalProvider({ children }: { children: ReactNode }) {
  const [mode, setMode] = useState<ModalMode>(null);

  const open = useCallback((m: Exclude<ModalMode, null>) => {
    setMode(m);
  }, []);

  const close = useCallback(() => {
    setMode(null);
  }, []);

  return (
    <EnquiryModalContext.Provider value={{ mode, open, close }}>
      {children}
    </EnquiryModalContext.Provider>
  );
}

export function useEnquiryModal() {
  const ctx = useContext(EnquiryModalContext);
  if (!ctx) throw new Error("useEnquiryModal must be used within EnquiryModalProvider");
  return ctx;
}
