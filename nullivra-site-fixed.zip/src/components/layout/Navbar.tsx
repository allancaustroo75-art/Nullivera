"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { navLinks } from "@/lib/data/services";
import { useEnquiryModal } from "@/lib/hooks/useEnquiryModal";
import { useScrollLock } from "@/lib/scroll-lock";
import styles from "./Navbar.module.css";
import { Wordmark } from "@/components/ui/Wordmark";

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const pathname = usePathname();
  const { open } = useEnquiryModal();

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 8);
    handler();
    window.addEventListener("scroll", handler, { passive: true });
    return () => window.removeEventListener("scroll", handler);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
  }, [pathname]);

  useScrollLock(mobileOpen);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") setMobileOpen(false);
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);

  const handleConsultation = () => {
    setMobileOpen(false);
    open("consultation");
  };

  return (
    <header
      className={`${styles.header} ${scrolled ? styles.scrolled : ""}`}
      data-mobile-open={mobileOpen}
    >
      <div className={styles.inner}>
        <Link href="/" className={styles.brand} aria-label="Nullivra home">
          <Wordmark />
        </Link>

        <nav className={styles.nav} aria-label="Primary">
          {navLinks.map((link) => {
            const active =
              link.href === pathname ||
              (link.href !== "/" && pathname.startsWith(link.href));
            return (
              <Link
                key={link.href}
                href={link.href}
                className={`${styles.navLink} ${active ? styles.active : ""}`}
              >
                {link.label}
              </Link>
            );
          })}
        </nav>

        <div className={styles.actions}>
          <button
            type="button"
            className={styles.cta}
            onClick={() => open("consultation")}
          >
            <span>Request a Consultation</span>
            <svg
              width="14"
              height="14"
              viewBox="0 0 14 14"
              fill="none"
              aria-hidden="true"
            >
              <path
                d="M3 7H11M11 7L7 3M11 7L7 11"
                stroke="currentColor"
                strokeWidth="1.4"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </button>

          <button
            type="button"
            className={styles.hamburger}
            aria-label={mobileOpen ? "Close menu" : "Open menu"}
            aria-expanded={mobileOpen}
            onClick={() => setMobileOpen((v) => !v)}
          >
            <span />
            <span />
          </button>
        </div>
      </div>

      <div
        className={`${styles.mobileMenu} ${mobileOpen ? styles.mobileOpen : ""}`}
        aria-hidden={!mobileOpen}
      >
        <nav className={styles.mobileNav} aria-label="Mobile">
          {navLinks.map((link, i) => (
            <Link
              key={link.href}
              href={link.href}
              className={styles.mobileLink}
              style={{ transitionDelay: mobileOpen ? `${100 + i * 40}ms` : "0ms" }}
            >
              <span className={styles.mobileLinkIndex}>
                0{i + 1}
              </span>
              {link.label}
            </Link>
          ))}
          <div className={styles.mobileFooter}>
            <button
              type="button"
              className={styles.mobileCta}
              onClick={handleConsultation}
            >
              Request a Consultation
            </button>
          </div>
        </nav>
      </div>
    </header>
  );
}
