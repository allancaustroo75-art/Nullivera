import { InsightsHero } from "@/components/sections/InsightsHero";
import { InsightsContent } from "@/components/sections/InsightsContent";
import { CaseCta } from "@/components/sections/CaseCta";

export const metadata = {
  title: "Insights — Nullivra",
  description:
    "Editorial perspective from Nullivra on brand protection, digital risk, impersonation, copyright and the modern digital surface.",
};

export default function InsightsPage() {
  return (
    <>
      <InsightsHero />
      <InsightsContent />
      <CaseCta />
    </>
  );
}
