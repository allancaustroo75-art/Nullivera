import { AboutHero } from "@/components/sections/AboutHero";
import { AboutContent } from "@/components/sections/AboutContent";
import { CaseCta } from "@/components/sections/CaseCta";

export const metadata = {
  title: "About — Nullivra",
  description:
    "Nullivra is a digital brand protection and digital risk management agency delivering structured, evidence-led case work for brands, creators and businesses.",
};

export default function AboutPage() {
  return (
    <>
      <AboutHero />
      <AboutContent />
      <CaseCta />
    </>
  );
}
