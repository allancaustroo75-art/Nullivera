import { Hero } from "@/components/sections/Hero";
import { Positioning } from "@/components/sections/Positioning";
import { Services } from "@/components/sections/Services";
import { Process } from "@/components/sections/Process";
import { WhyNullivra } from "@/components/sections/WhyNullivra";
import { Audiences } from "@/components/sections/Audiences";
import { ResponseTimes } from "@/components/sections/ResponseTimes";
import { CaseCta } from "@/components/sections/CaseCta";

export default function Home() {
  return (
    <>
      <Hero />
      <Positioning />
      <Services />
      <Process />
      <WhyNullivra />
      <Audiences />
      <ResponseTimes />
      <CaseCta />
    </>
  );
}
