import { ReactNode } from "react";

export const metadata = {
  title: "Admin sign in — Nullivra",
  robots: { index: false, follow: false },
};

export default function AdminLoginLayout({ children }: { children: ReactNode }) {
  // No admin shell, no auth required for the login page itself.
  return <>{children}</>;
}
