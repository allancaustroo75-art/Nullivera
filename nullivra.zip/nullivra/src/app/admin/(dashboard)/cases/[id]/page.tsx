import { notFound } from "next/navigation";
import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/session";
import { StatusPill } from "@/components/admin/StatusPill";
import { CaseControls } from "@/components/admin/CaseControls";
import { NotesClient } from "@/components/admin/NotesClient";
import { platformGroups, issueCategories, getPlatformTAT } from "@/lib/data/services";
import styles from "./detail.module.css";

export const dynamic = "force-dynamic";

const STATUS_LABELS: Record<string, string> = {
  NEW: "New",
  REVIEWING: "Reviewing",
  CONTACTED: "Contacted",
  IN_PROGRESS: "In Progress",
  RESOLVED: "Resolved",
  CLOSED: "Closed",
};

type NoteWithAuthor = {
  id: string;
  body: string;
  createdAt: Date;
  author: { name: string | null; email: string | null };
};

// Helper: look up a platform slug or issueType slug into a human label
function labelFor(slug: string, source: { value: string; label: string }[]): string {
  return source.find((x) => x.value === slug)?.label || slug;
}

function platformLabel(slug: string | null): string {
  if (!slug) return "—";
  for (const g of platformGroups) {
    const p = g.platforms.find((x) => x.value === slug);
    if (p) return p.label;
  }
  return slug;
}

function issueLabel(slug: string | null): string {
  if (!slug) return "—";
  return issueCategories.find((x) => x.value === slug)?.label || slug;
}

export default async function AdminCaseDetail({ params }: { params: { id: string } }) {
  await requireAdmin();

  const c = await prisma.case.findUnique({
    where: { id: params.id },
    include: {
      files: { orderBy: { createdAt: "desc" } },
      notes: {
        orderBy: { createdAt: "desc" },
        include: { author: { select: { name: true, email: true } } },
      },
      activities: {
        orderBy: { createdAt: "desc" },
        take: 30,
        include: { actor: { select: { name: true, email: true } } },
      },
    },
  });

  if (!c) notFound();

  const relevantUrls = c.relevantUrls?.split("\n").map((s) => s.trim()).filter(Boolean) || [];
  const notesData: NoteWithAuthor[] = c.notes.map((n) => ({
    id: n.id,
    body: n.body,
    createdAt: n.createdAt,
    author: n.author,
  }));

  return (
    <div className={styles.page}>
      <Link href="/admin" className={styles.back}>← All cases</Link>

      <header className={styles.header}>
        <div className={styles.headerTop}>
          <div>
            <span className={styles.ref}>{c.reference}</span>
            <h1 className={styles.title}>
              {platformLabel(c.platform)} · {issueLabel(c.issueType)}
            </h1>
            <p className={styles.subtitle}>
              Submitted by <span className={styles.clientName}>{c.fullName}</span>
              {c.company && <> · <span className={styles.company}>{c.company}</span></>}
            </p>
          </div>
          <StatusPill status={c.status} />
        </div>
      </header>

      <CaseControls caseId={c.id} initialStatus={c.status} />

      <div className={styles.grid}>
        <div className={styles.main}>
          <section className={styles.section}>
            <h2 className={styles.sectionTitle}>Description</h2>
            <div className={styles.description}>{c.description}</div>
          </section>

          {relevantUrls.length > 0 && (
            <section className={styles.section}>
              <h2 className={styles.sectionTitle}>Relevant URLs</h2>
              <ul className={styles.urlList}>
                {relevantUrls.map((u, i) => (
                  <li key={i}><a href={u} target="_blank" rel="noreferrer" className={styles.link}>{u}</a></li>
                ))}
              </ul>
            </section>
          )}

          {c.files.length > 0 && (
            <section className={styles.section}>
              <h2 className={styles.sectionTitle}>Evidence / Files ({c.files.length})</h2>
              <ul className={styles.fileList}>
                {c.files.map((f) => (
                  <li key={f.id} className={styles.fileItem}>
                    <div className={styles.fileInfo}>
                      <span className={styles.fileName}>{f.filename}</span>
                      <span className={styles.fileSize}>
                        {(f.size / 1024).toFixed(0)} KB · {f.mimeType}
                      </span>
                    </div>
                    <a
                      href={`/api/files/${f.id}`}
                      target="_blank"
                      rel="noreferrer"
                      className={styles.fileLink}
                    >
                      Download
                    </a>
                  </li>
                ))}
              </ul>
            </section>
          )}

          <NotesClient caseId={c.id} initialNotes={notesData} />
        </div>

        <aside className={styles.aside}>
          <section className={styles.asideSection}>
            <h3 className={styles.asideTitle}>Client contact</h3>
            <dl className={styles.asideList}>
              <div><dt>Name</dt><dd>{c.fullName}</dd></div>
              <div><dt>Email</dt><dd className={styles.mono}>{c.email}</dd></div>
              {c.phone && <div><dt>Phone</dt><dd className={styles.mono}>{c.phone}</dd></div>}
              {c.company && <div><dt>Company</dt><dd>{c.company}</dd></div>}
              <div><dt>Country</dt><dd>{c.country}</dd></div>
              {c.websiteUrl && (
                <div>
                  <dt>Website</dt>
                  <dd>
                    <a href={c.websiteUrl} target="_blank" rel="noreferrer" className={styles.link}>
                      {c.websiteUrl}
                    </a>
                  </dd>
                </div>
              )}
            </dl>
            <div className={styles.contactActions}>
              <a
                href={`mailto:${c.email}?subject=Re: ${c.reference} — Nullivra`}
                className={styles.emailBtn}
              >
                <svg width="14" height="14" viewBox="0 0 16 16" fill="none">
                  <rect x="2" y="3.5" width="12" height="9" rx="1" stroke="currentColor" strokeWidth="1.4"/>
                  <path d="M2 4l6 4 6-4" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
                <span>Email client</span>
              </a>
              {c.phone && (
                <a
                  href={`tel:${c.phone.replace(/\s/g, "")}`}
                  className={styles.phoneBtn}
                >
                  <svg width="14" height="14" viewBox="0 0 16 16" fill="none">
                    <path
                      d="M3 3.5C3 3.22 3.22 3 3.5 3H5.7c5.74 0 9.3 5.56 9.3 9.3v.2a.5.5 0 0 1-.5.5h-2.2a.5.5 0 0 1-.5-.5v-1.6c0-.28.22-.5.5-.5h1.3a8 8 0 0 0-7.6-7.6V4.3c0-.28-.22-.5-.5-.5H3.5a.5.5 0 0 1-.5-.5v-.3Z"
                      transform="translate(0 0)"
                      stroke="currentColor"
                      strokeWidth="1.4"
                      strokeLinejoin="round"
                    />
                  </svg>
                  <span>Call client</span>
                </a>
              )}
            </div>
          </section>

          <section className={styles.asideSection}>
            <h3 className={styles.asideTitle}>Case info</h3>
            <dl className={styles.asideList}>
              <div><dt>Reference</dt><dd className={styles.mono}>{c.reference}</dd></div>
              <div><dt>Platform</dt><dd>{platformLabel(c.platform)}</dd></div>
              <div><dt>Issue</dt><dd>{issueLabel(c.issueType)}</dd></div>
              <div><dt>Status</dt><dd>{STATUS_LABELS[c.status] || c.status}</dd></div>
              <div><dt>Submitted</dt><dd>{new Date(c.createdAt).toLocaleString()}</dd></div>
              {c.closedAt && <div><dt>Closed</dt><dd>{new Date(c.closedAt).toLocaleString()}</dd></div>}
            </dl>
            {getPlatformTAT(c.platform) && (
              <div className={styles.tatInfo}>
                <span className={styles.tatInfoLabel}>Typical response window</span>
                <span className={styles.tatInfoValue}>
                  {getPlatformTAT(c.platform)!.window}
                </span>
                {getPlatformTAT(c.platform)!.note && (
                  <span className={styles.tatInfoNote}>
                    {getPlatformTAT(c.platform)!.note}
                  </span>
                )}
              </div>
            )}
          </section>

          <section className={styles.asideSection}>
            <h3 className={styles.asideTitle}>Activity log</h3>
            {c.activities.length === 0 ? (
              <p className={styles.asideEmpty}>No activity yet.</p>
            ) : (
              <ul className={styles.activityList}>
                {c.activities.map((a) => (
                  <li key={a.id} className={styles.activityItem}>
                    <span className={styles.activityDot} />
                    <div>
                      <div className={styles.activityType}>{a.type.replace(/_/g, " ").toLowerCase()}</div>
                      <div className={styles.activityMeta}>
                        {a.actor?.name || a.actor?.email || "system"} · {new Date(a.createdAt).toLocaleString()}
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </section>
        </aside>
      </div>
    </div>
  );
}
