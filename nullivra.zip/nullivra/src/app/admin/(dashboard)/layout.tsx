import { ReactNode } from "react";
import { requireAdmin } from "@/lib/session";
import { AdminShell } from "@/components/admin/AdminShell";

export const metadata = {
  title: "Admin — Nullivra",
  robots: { index: false, follow: false },
};

export default async function AdminLayout({ children }: { children: ReactNode }) {
  const user = await requireAdmin();
  return <AdminShell user={{ name: user.name, email: user.email }}>{children}</AdminShell>;
}
