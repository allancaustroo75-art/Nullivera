import Link from "next/link";
import { Prisma } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { StatusPill } from "@/components/admin/StatusPill";
import { platformGroups, issueCategories } from "@/lib/data/services";
import styles from "./admin.module.css";

export const dynamic = "force-dynamic";

const STATUSES = ["ALL", "NEW", "REVIEWING", "CONTACTED", "IN_PROGRESS", "RESOLVED", "CLOSED"] as const;

function platformLabel(slug: string | null): string {
  if (!slug) return "—";
  for (const g of platformGroups) {
    const p = g.platforms.find((x) => x.value === slug);
    if (p) return p.label;
  }
  return slug;
}

function issueLabel(slug: string | null): string {
  if (!slug) return "—";
  return issueCategories.find((x) => x.value === slug)?.label || slug;
}

export default async function AdminCasesPage({
  searchParams,
}: {
  searchParams: { status?: string; q?: string };
}) {
  const status = (searchParams.status || "ALL") as (typeof STATUSES)[number];
  const q = (searchParams.q || "").trim();

  const where: Prisma.CaseWhereInput = {};
  if (status !== "ALL") where.status = status as Prisma.EnumCaseStatusFilter;
  if (q) {
    where.OR = [
      { reference: { contains: q } },
      { fullName: { contains: q } },
      { email: { contains: q } },
      { company: { contains: q } },
      { country: { contains: q } },
      { phone: { contains: q } },
      { platform: { contains: q } },
      { issueType: { contains: q } },
      { description: { contains: q } },
    ];
  }

  const [cases, counts] = await Promise.all([
    prisma.case.findMany({
      where,
      orderBy: { createdAt: "desc" },
    }),
    prisma.case.groupBy({ by: ["status"], _count: true }),
  ]);

  const total = counts.reduce((s, c) => s + c._count, 0);
  const newCount = counts.find((c) => c.status === "NEW")?._count || 0;
  const inProgress = counts
    .filter((c) => ["REVIEWING", "CONTACTED", "IN_PROGRESS"].includes(c.status))
    .reduce((s, c) => s + c._count, 0);
  const resolved = (counts.find((c) => c.status === "RESOLVED")?._count || 0)
    + (counts.find((c) => c.status === "CLOSED")?._count || 0);

  return (
    <div className={styles.page}>
      <header className={styles.header}>
        <div>
          <span className={styles.eyebrow}>Enquiries</span>
          <h1 className={styles.title}>Case management</h1>
        </div>
      </header>

      <div className={styles.stats}>
        <div className={styles.stat}>
          <span className={styles.statLabel}>Total</span>
          <span className={styles.statValue}>{total}</span>
        </div>
        <div className={styles.stat}>
          <span className={styles.statLabel}>New</span>
          <span className={styles.statValue} style={{ color: "#4a8eff" }}>{newCount}</span>
        </div>
        <div className={styles.stat}>
          <span className={styles.statLabel}>In progress</span>
          <span className={styles.statValue} style={{ color: "#f5b042" }}>{inProgress}</span>
        </div>
        <div className={styles.stat}>
          <span className={styles.statLabel}>Resolved / Closed</span>
          <span className={styles.statValue} style={{ color: "#4ade80" }}>{resolved}</span>
        </div>
      </div>

      <form className={styles.toolbar} method="GET">
        <input
          type="text"
          name="q"
          defaultValue={q}
          placeholder="Search reference, name, email, phone, company, country, platform, issue…"
          className={styles.search}
        />
        <div className={styles.chips}>
          {STATUSES.map((s) => (
            <button
              key={s}
              type="submit"
              name="status"
              value={s}
              className={`${styles.chip} ${status === s ? styles.chipActive : ""}`}
            >
              {s === "ALL" ? "All" : s.charAt(0) + s.slice(1).toLowerCase().replace("_", " ")}
            </button>
          ))}
        </div>
      </form>

      <div className={styles.results}>
        {cases.length === 0 ? (
          <div className={styles.empty}>No cases match the current filters.</div>
        ) : (
          <table className={styles.table}>
            <thead>
              <tr>
                <th>Reference</th>
                <th>Client</th>
                <th>Platform</th>
                <th>Issue</th>
                <th>Country</th>
                <th>Status</th>
                <th>Submitted</th>
              </tr>
            </thead>
            <tbody>
              {cases.map((c) => (
                <tr key={c.id}>
                  <td>
                    <Link href={`/admin/cases/${c.id}`} className={styles.refLink}>
                      {c.reference}
                    </Link>
                  </td>
                  <td>
                    <div className={styles.clientCell}>
                      <span>{c.fullName}</span>
                      {c.company && <span className={styles.company}>{c.company}</span>}
                    </div>
                  </td>
                  <td className={styles.platform}>{platformLabel(c.platform)}</td>
                  <td>{issueLabel(c.issueType)}</td>
                  <td className={styles.country}>{c.country}</td>
                  <td><StatusPill status={c.status} /></td>
                  <td className={styles.date}>
                    {new Date(c.createdAt).toLocaleString("en", {
                      day: "2-digit", month: "short", year: "numeric",
                      hour: "2-digit", minute: "2-digit",
                    })}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
