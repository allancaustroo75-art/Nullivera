import type { Metadata, Viewport } from "next";
import { Inter, Instrument_Serif, JetBrains_Mono } from "next/font/google";
import { Providers } from "@/components/Providers";
import "./globals.css";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
});

const instrumentSerif = Instrument_Serif({
  subsets: ["latin"],
  weight: "400",
  variable: "--font-display",
  display: "swap",
});

const jetbrains = JetBrains_Mono({
  subsets: ["latin"],
  variable: "--font-mono",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Nullivra — Digital Brand Protection & Digital Risk Management",
  description:
    "Nullivra helps brands, creators and businesses identify, manage and respond to digital threats that put their identity, content and reputation at risk.",
  metadataBase: new URL("https://nullivra.com"),
  openGraph: {
    title: "Nullivra — Digital Brand Protection & Digital Risk Management",
    description:
      "Structured digital protection for brands, creators and businesses facing impersonation, copyright infringement, and emerging digital risks.",
    type: "website",
    siteName: "Nullivra",
  },
  robots: {
    index: true,
    follow: true,
  },
};

export const viewport: Viewport = {
  themeColor: "#06080d",
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html
      lang="en"
      className={`${inter.variable} ${instrumentSerif.variable} ${jetbrains.variable}`}
    >
      <body>
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
