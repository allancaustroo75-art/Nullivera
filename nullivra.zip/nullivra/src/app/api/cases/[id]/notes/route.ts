import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export const runtime = "nodejs";

const Schema = z.object({
  body: z.string().min(1).max(5000),
});

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    if (session.user.role !== "ADMIN") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const json = await req.json();
    const parsed = Schema.safeParse(json);
    if (!parsed.success) return NextResponse.json({ error: "Invalid input" }, { status: 400 });

    const existing = await prisma.case.findUnique({ where: { id: params.id } });
    if (!existing) return NextResponse.json({ error: "Case not found" }, { status: 404 });

    const note = await prisma.note.create({
      data: {
        caseId: existing.id,
        authorId: session.user.id,
        body: parsed.data.body,
      },
    });

    await prisma.activity.create({
      data: {
        caseId: existing.id,
        actorId: session.user.id,
        type: "NOTE_ADDED",
        payload: JSON.stringify({ noteId: note.id, length: parsed.data.body.length }),
      },
    });

    return NextResponse.json({ ok: true, id: note.id });
  } catch (e) {
    console.error("Note create error:", e);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
