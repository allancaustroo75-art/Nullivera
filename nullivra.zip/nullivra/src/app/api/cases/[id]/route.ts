import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export const runtime = "nodejs";

const Schema = z.object({
  status: z.enum(["NEW", "REVIEWING", "CONTACTED", "IN_PROGRESS", "RESOLVED", "CLOSED"]).optional(),
});

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    if (session.user.role !== "ADMIN") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const body = await req.json();
    const parsed = Schema.safeParse(body);
    if (!parsed.success) return NextResponse.json({ error: "Invalid input" }, { status: 400 });

    const existing = await prisma.case.findUnique({ where: { id: params.id } });
    if (!existing) return NextResponse.json({ error: "Case not found" }, { status: 404 });

    const data: Record<string, unknown> = {};
    const changes: string[] = [];

    if (parsed.data.status && parsed.data.status !== existing.status) {
      data.status = parsed.data.status;
      changes.push(`Status: ${existing.status} → ${parsed.data.status}`);
      if (parsed.data.status === "RESOLVED" || parsed.data.status === "CLOSED") {
        data.closedAt = new Date();
      } else {
        data.closedAt = null;
      }
    }

    if (Object.keys(data).length === 0) {
      return NextResponse.json({ ok: true, noChange: true });
    }

    const updated = await prisma.case.update({
      where: { id: params.id },
      data,
    });

    await prisma.activity.create({
      data: {
        caseId: existing.id,
        actorId: session.user.id,
        type: "STATUS_CHANGED",
        payload: JSON.stringify({ changes }),
      },
    });

    return NextResponse.json({ ok: true, case: updated });
  } catch (e) {
    console.error("Case update error:", e);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
