import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export const runtime = "nodejs";

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session?.user || session.user.role !== "ADMIN") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const file = await prisma.caseFile.findUnique({ where: { id: params.id } });
  if (!file) return NextResponse.json({ error: "Not found" }, { status: 404 });

  // storedAs is now a Vercel Blob URL — fetch it server-side so the
  // admin-only check above still gates access (the blob URL itself is
  // public/unguessable, but we don't want to just redirect and skip auth).
  const blobRes = await fetch(file.storedAs);
  if (!blobRes.ok) {
    return NextResponse.json({ error: "File not found in storage" }, { status: 404 });
  }
  const buf = Buffer.from(await blobRes.arrayBuffer());

  return new NextResponse(buf, {
    status: 200,
    headers: {
      "Content-Type": file.mimeType,
      "Content-Disposition": `attachment; filename="${encodeURIComponent(file.filename)}"`,
      "Content-Length": String(file.size),
    },
  });
}
