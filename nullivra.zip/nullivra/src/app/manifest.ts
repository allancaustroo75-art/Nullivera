import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "Nullivra — Digital Brand Protection",
    short_name: "Nullivra",
    description:
      "Digital Brand Protection & Digital Risk Management for brands, creators and businesses.",
    start_url: "/",
    display: "standalone",
    background_color: "#06080d",
    theme_color: "#06080d",
    icons: [
      {
        src: "/icon.svg",
        sizes: "any",
        type: "image/svg+xml",
      },
    ],
  };
}
