"use client";

import { useEffect, useRef } from "react";
import styles from "./HeroVisual.module.css";

/**
 * Sophisticated abstract digital network visual.
 * Pure SVG/Canvas — no external images. Slow, restrained animation.
 */
export function HeroVisual() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rafRef = useRef<number | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let width = 0;
    let height = 0;
    let dpr = 1;
    const reduced =
      typeof window !== "undefined" &&
      window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    type Node = {
      x: number;
      y: number;
      vx: number;
      vy: number;
      r: number;
      pulse: number;
      pulseSpeed: number;
    };

    let nodes: Node[] = [];
    let mouseX = -1000;
    let mouseY = -1000;
    let time = 0;

    const NODE_COUNT = 38;
    const MAX_DIST = 160;

    function init() {
      const rect = canvas!.getBoundingClientRect();
      width = rect.width;
      height = rect.height;
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas!.width = width * dpr;
      canvas!.height = height * dpr;
      ctx!.scale(dpr, dpr);

      nodes = [];
      for (let i = 0; i < NODE_COUNT; i++) {
        nodes.push({
          x: Math.random() * width,
          y: Math.random() * height,
          vx: (Math.random() - 0.5) * 0.12,
          vy: (Math.random() - 0.5) * 0.12,
          r: Math.random() * 1.6 + 0.6,
          pulse: Math.random() * Math.PI * 2,
          pulseSpeed: 0.005 + Math.random() * 0.012,
        });
      }
    }

    function draw() {
      if (!ctx) return;
      ctx.clearRect(0, 0, width, height);
      time += 0.5;

      // Update positions
      if (!reduced) {
        for (const n of nodes) {
          n.x += n.vx;
          n.y += n.vy;
          n.pulse += n.pulseSpeed;

          if (n.x < 0 || n.x > width) n.vx *= -1;
          if (n.y < 0 || n.y > height) n.vy *= -1;
        }
      }

      // Draw connections
      for (let i = 0; i < nodes.length; i++) {
        const a = nodes[i];

        // Mouse interaction
        const dxm = a.x - mouseX;
        const dym = a.y - mouseY;
        const distM = Math.sqrt(dxm * dxm + dym * dym);
        if (distM < 140) {
          const alpha = (1 - distM / 140) * 0.35;
          ctx.beginPath();
          ctx.moveTo(a.x, a.y);
          ctx.lineTo(mouseX, mouseY);
          ctx.strokeStyle = `rgba(74, 142, 255, ${alpha})`;
          ctx.lineWidth = 0.8;
          ctx.stroke();
        }

        for (let j = i + 1; j < nodes.length; j++) {
          const b = nodes[j];
          const dx = a.x - b.x;
          const dy = a.y - b.y;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < MAX_DIST) {
            const alpha = (1 - dist / MAX_DIST) * 0.22;
            ctx.beginPath();
            ctx.moveTo(a.x, a.y);
            ctx.lineTo(b.x, b.y);
            ctx.strokeStyle = `rgba(140, 170, 220, ${alpha})`;
            ctx.lineWidth = 0.5;
            ctx.stroke();
          }
        }
      }

      // Draw nodes
      for (const n of nodes) {
        const pulseSize = reduced ? 1 : 1 + Math.sin(n.pulse) * 0.4;
        const baseAlpha = 0.55;
        const alpha = baseAlpha + Math.sin(n.pulse) * 0.15;

        // Outer glow
        const gradient = ctx.createRadialGradient(
          n.x,
          n.y,
          0,
          n.x,
          n.y,
          n.r * 8 * pulseSize
        );
        gradient.addColorStop(0, `rgba(74, 142, 255, ${alpha * 0.4})`);
        gradient.addColorStop(1, "rgba(74, 142, 255, 0)");
        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.arc(n.x, n.y, n.r * 8 * pulseSize, 0, Math.PI * 2);
        ctx.fill();

        // Core
        ctx.beginPath();
        ctx.arc(n.x, n.y, n.r * pulseSize, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(180, 210, 255, ${alpha})`;
        ctx.fill();
      }
    }

    function loop() {
      draw();
      rafRef.current = requestAnimationFrame(loop);
    }

    function handleMouse(e: MouseEvent) {
      if (!canvas) return;
      const rect = canvas.getBoundingClientRect();
      mouseX = e.clientX - rect.left;
      mouseY = e.clientY - rect.top;
    }

    function handleLeave() {
      mouseX = -1000;
      mouseY = -1000;
    }

    function handleResize() {
      init();
    }

    init();
    loop();

    canvas.addEventListener("mousemove", handleMouse);
    canvas.addEventListener("mouseleave", handleLeave);
    window.addEventListener("resize", handleResize);

    return () => {
      if (rafRef.current !== null) cancelAnimationFrame(rafRef.current);
      canvas.removeEventListener("mousemove", handleMouse);
      canvas.removeEventListener("mouseleave", handleLeave);
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  return (
    <div className={styles.wrap} aria-hidden="true">
      <canvas ref={canvasRef} className={styles.canvas} />
      <div className={styles.frame}>
        {/* Corner ticks */}
        <span className={`${styles.tick} ${styles.tl}`} />
        <span className={`${styles.tick} ${styles.tr}`} />
        <span className={`${styles.tick} ${styles.bl}`} />
        <span className={`${styles.tick} ${styles.br}`} />
        {/* Coordinates labels */}
        <span className={`${styles.label} ${styles.labelTL}`}>
          N · 26.9124
        </span>
        <span className={`${styles.label} ${styles.labelBR}`}>
          E · 75.7873
        </span>
        <span className={`${styles.label} ${styles.labelBL}`}>
          SESSION · ENCRYPTED
        </span>
        <span className={`${styles.label} ${styles.labelTR}`}>
          IDENTITY · LAYER
        </span>
        {/* Sweep line */}
        <div className={styles.sweep} />
      </div>
    </div>
  );
}
