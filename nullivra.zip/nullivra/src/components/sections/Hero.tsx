"use client";

import { useEffect, useRef } from "react";
import { EnquiryModalButton } from "@/components/ui/EnquiryModalButton";
import { HeroVisual } from "@/components/hero-visual/HeroVisual";
import styles from "./Hero.module.css";

export function Hero() {
  const headlineRef = useRef<HTMLHeadingElement>(null);

  useEffect(() => {
    // Reveal the headline as a single unit, on mount.
    // Graceful no-JS / no-motion fallback shows the headline by default.
    const el = headlineRef.current;
    if (!el) return;
    requestAnimationFrame(() => el.classList.add(styles.headlineIn));
  }, []);

  return (
    <section className={styles.hero}>
      <div className={styles.bgGlow} aria-hidden="true" />
      <div className={styles.bgGrid} aria-hidden="true" />

      <div className={styles.container}>
        <div className={styles.content}>
          <div className={styles.eyebrow}>
            <span className={styles.dot} />
            <span>Digital Brand Protection Agency</span>
            <span className={styles.line} />
          </div>

          <h1 ref={headlineRef} className={styles.headline}>
            <span className={styles.line}>Protecting Your</span>
            <span className={styles.line}>
              <span className={styles.italic}>Digital Identity.</span>
            </span>
            <span className={styles.line}>Preserving Your Brand.</span>
          </h1>

          <p className={styles.lede}>
            Nullivra helps brands, creators and businesses identify, manage and
            respond to digital threats that put their identity, content and
            reputation at risk.
          </p>

          <div className={styles.ctas}>
            <EnquiryModalButton mode="consultation" variant="primary">
              Request a Consultation
              <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden="true">
                <path
                  d="M3 7H11M11 7L7 3M11 7L7 11"
                  stroke="currentColor"
                  strokeWidth="1.6"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </EnquiryModalButton>
            <a href="#services" className={styles.secondary}>
              <span>Explore Services</span>
              <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden="true">
                <path
                  d="M7 3V11M7 11L3 7M7 11L11 7"
                  stroke="currentColor"
                  strokeWidth="1.4"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </a>
          </div>

          <div className={styles.metaRow}>
            <div className={styles.metaItem}>
              <span className={styles.metaLabel}>Scope</span>
              <span className={styles.metaValue}>Identity · Content · Risk</span>
            </div>
            <div className={styles.metaItem}>
              <span className={styles.metaLabel}>Coverage</span>
              <span className={styles.metaValue}>Global Digital Surface</span>
            </div>
            <div className={styles.metaItem}>
              <span className={styles.metaLabel}>Approach</span>
              <span className={styles.metaValue}>Structured Workflows</span>
            </div>
          </div>
        </div>

        <div className={styles.visual}>
          <HeroVisual />
        </div>
      </div>

      <a href="#positioning" className={styles.scrollHint} aria-label="Scroll to next section">
        <span className={styles.scrollLine} />
        <span className={styles.scrollLabel}>Scroll</span>
      </a>
    </section>
  );
}
