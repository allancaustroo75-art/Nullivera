import { platformGroups, getPlatformTAT } from "@/lib/data/services";
import styles from "./ResponseTimes.module.css";

export function ResponseTimes() {
  // Flatten every platform that has a defined TAT window
  const items = platformGroups
    .flatMap((g) => g.platforms)
    .filter((p) => p.value !== "not-sure" && p.value !== "multiple")
    .map((p) => ({
      value: p.value,
      label: p.label,
      tat: getPlatformTAT(p.value),
    }))
    .filter((p) => p.tat !== null);

  return (
    <section className={styles.section}>
      <div className="container">
        <div className={styles.header}>
          <div className={styles.eyebrow}>
            <span className={styles.dot} />
            <span>07 — Response windows</span>
          </div>
          <h2 className={styles.title}>
            Typical response time{" "}
            <span className={styles.italic}>by platform.</span>
          </h2>
          <p className={styles.lede}>
            How long it usually takes for us to complete an initial review and
            submit the first enforcement request after a case is opened.
            Actual timelines vary by case complexity, evidence quality, and
            the responding platform&apos;s own process.
          </p>
        </div>

        <div className={styles.listWrap}>
          <ul className={styles.list}>
            {items.map((item) => (
              <li key={item.value} className={styles.row}>
                <span className={styles.platform}>{item.label}</span>
                <span className={styles.tat}>{item.tat?.window}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className={styles.disclaimer}>
          <span className={styles.disclaimerIcon}>
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
              <circle cx="7" cy="7" r="6" stroke="currentColor" strokeWidth="1.2" />
              <path d="M7 4V8M7 10V10.5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" />
            </svg>
          </span>
          <p>
            Typical windows reflect initial review and first submission, not
            guaranteed resolution. Final outcomes depend on evidence,
            platform cooperation, and case complexity. Other platforms and
            multi-surface cases are handled on a per-case basis.
          </p>
        </div>
      </div>
    </section>
  );
}
