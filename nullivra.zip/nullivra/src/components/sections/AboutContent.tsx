import { processSteps, principles } from "@/lib/data/services";
import styles from "./AboutContent.module.css";

export function AboutContent() {
  return (
    <>
      <section className={`section ${styles.pillars}`}>
        <div className="container">
          <div className={styles.header}>
            <span className={styles.eyebrow}>
              <span className={styles.dot} />
              <span>What Defines Us</span>
            </span>
            <h2 className={styles.title}>
              The principles that shape{" "}
              <span className={styles.italic}>every engagement.</span>
            </h2>
          </div>
          <div className={styles.grid}>
            {principles.map((p, i) => (
              <div key={p.title} className={styles.card}>
                <span className={styles.cardIndex}>0{i + 1}</span>
                <h3 className={styles.cardTitle}>{p.title}</h3>
                <p className={styles.cardDesc}>{p.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={`section ${styles.methodology}`}>
        <div className="container">
          <div className={styles.methodHeader}>
            <span className={styles.eyebrow}>
              <span className={styles.dot} />
              <span>Methodology</span>
            </span>
            <h2 className={styles.title}>
              A defined path from{" "}
              <span className={styles.italic}>intake to resolution.</span>
            </h2>
            <p className={styles.lede}>
              Every case at Nullivra follows the same four-stage professional
              framework — applied with discretion, adapted to the situation,
              and documented at every step.
            </p>
          </div>
          <ol className={styles.steps}>
            {processSteps.map((step, i) => (
              <li key={step.number} className={styles.step}>
                <div className={styles.stepHead}>
                  <span className={styles.stepNumber}>{step.number}</span>
                  <h3 className={styles.stepTitle}>{step.title}</h3>
                </div>
                <p className={styles.stepDesc}>{step.description}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section className={`section ${styles.commitment}`}>
        <div className="container">
          <div className={styles.commitGrid}>
            <div className={styles.commitLeft}>
              <span className={styles.eyebrow}>
                <span className={styles.dot} />
                <span>What We Will Not Do</span>
              </span>
              <h2 className={styles.title}>
                Boundaries that protect{" "}
                <span className={styles.italic}>our clients.</span>
              </h2>
            </div>
            <div className={styles.commitRight}>
              <p className={styles.commitText}>
                We do not make unrealistic promises about guaranteed
                resolutions, time-bound removals or fixed outcomes. We do not
                rely on automated mass-reporting tools, and we do not present
                our work as a substitute for legal counsel.
              </p>
              <p className={styles.commitText}>
                We do not publish fabricated statistics, client logos or
                testimonials. We do not imitate the surface of a larger firm —
                we operate as a focused, structured agency with a clear scope
                of practice.
              </p>
              <p className={styles.commitText}>
                Every client engagement is governed by the same professional
                standards: confidentiality, evidence, and disciplined case
                management.
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
