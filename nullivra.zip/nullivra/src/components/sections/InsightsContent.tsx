"use client";

import { useState } from "react";
import { insightArticles, insightCategories } from "@/lib/data/services";
import styles from "./InsightsContent.module.css";

type Article = {
  slug: string;
  category: string;
  title: string;
  excerpt: string;
  readTime: string;
  date: string;
  featured?: boolean;
};

export function InsightsContent({ articles }: { articles?: Article[] }) {
  const source = articles || insightArticles;
  const [active, setActive] = useState<string>("all");

  const filtered =
    active === "all"
      ? source
      : source.filter((a) => a.category === active);

  const featured = filtered.find((a) => a.featured) || filtered[0];
  const rest = filtered.filter((a) => a !== featured);

  return (
    <section className={`section ${styles.section}`}>
      <div className="container">
        <div className={styles.filters}>
          <button
            type="button"
            className={`${styles.chip} ${active === "all" ? styles.chipActive : ""}`}
            onClick={() => setActive("all")}
          >
            All
          </button>
          {insightCategories.map((c) => (
            <button
              key={c.slug}
              type="button"
              className={`${styles.chip} ${active === c.slug ? styles.chipActive : ""}`}
              onClick={() => setActive(c.slug)}
            >
              {c.label}
            </button>
          ))}
        </div>

        {featured && (
          <article className={styles.featured}>
            <div className={styles.featuredLeft}>
              <span className={styles.featuredLabel}>
                <span className={styles.dot} />
                Featured
              </span>
              <span className={styles.category}>
                {getCategoryLabel(featured.category)}
              </span>
              <h2 className={styles.featuredTitle}>{featured.title}</h2>
              <p className={styles.featuredExcerpt}>{featured.excerpt}</p>
              <div className={styles.meta}>
                <span>Editorial</span>
                <span className={styles.dot} />
                <span>Article placeholder</span>
              </div>
            </div>
            <div className={styles.featuredVisual} aria-hidden="true">
              <div className={styles.visualGrid} />
              <span className={styles.visualMark}>
                {getCategoryLabel(featured.category).toUpperCase()}
              </span>
              <span className={styles.visualTickTL} />
              <span className={styles.visualTickTR} />
              <span className={styles.visualTickBL} />
              <span className={styles.visualTickBR} />
            </div>
          </article>
        )}

        <div className={styles.grid}>
          {rest.map((a) => (
            <article key={a.slug} className={styles.card}>
              <div className={styles.cardTop}>
                <span className={styles.cardCategory}>
                  {getCategoryLabel(a.category)}
                </span>
                <span className={styles.cardArrow} aria-hidden="true">
                  <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                    <path
                      d="M3 11L11 3M11 3H5M11 3V9"
                      stroke="currentColor"
                      strokeWidth="1.4"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </span>
              </div>
              <h3 className={styles.cardTitle}>{a.title}</h3>
              <p className={styles.cardExcerpt}>{a.excerpt}</p>
              <div className={styles.cardFoot}>
                <span className={styles.cardMeta}>Editorial</span>
                <span className={styles.cardDot} />
                <span className={styles.cardMeta}>Article placeholder</span>
              </div>
            </article>
          ))}
        </div>

        <div className={styles.note}>
          <span className={styles.noteIcon}>
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
              <circle cx="7" cy="7" r="6" stroke="currentColor" strokeWidth="1.2" />
              <path
                d="M7 4V8M7 10V10.5"
                stroke="currentColor"
                strokeWidth="1.4"
                strokeLinecap="round"
              />
            </svg>
          </span>
          <p>
            This section is structured as a frontend placeholder. Real
            articles can be connected through a CMS or backend integration
            without rebuilding the layout.
          </p>
        </div>
      </div>
    </section>
  );
}

function getCategoryLabel(slug: string): string {
  return (
    insightCategories.find((c) => c.slug === slug)?.label || "Editorial"
  );
}
