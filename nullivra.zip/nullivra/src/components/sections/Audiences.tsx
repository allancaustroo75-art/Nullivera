import { audiences } from "@/lib/data/services";
import styles from "./Audiences.module.css";

export function Audiences() {
  return (
    <section className={`section ${styles.section}`}>
      <div className="container">
        <div className={styles.header}>
          <div className={styles.eyebrow}>
            <span className={styles.dot} />
            <span>05 — Practice</span>
          </div>
          <h2 className={styles.title}>
            Built For Brands That Have{" "}
            <span className={styles.italic}>Something Worth Protecting.</span>
          </h2>
          <p className={styles.lede}>
            Whether you&rsquo;re building a personal brand, growing a company
            or managing a large digital presence, your online identity deserves
            protection.
          </p>
        </div>

        <div className={styles.grid}>
          {audiences.map((a, i) => (
            <div
              key={a.label}
              className={`${styles.tile} reveal reveal-delay-${(i % 6) + 1}`}
            >
              <div className={styles.tileTop}>
                <span className={styles.tileIndex}>
                  0{i + 1}
                </span>
                <span className={styles.tileArrow} aria-hidden="true">
                  <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                    <path
                      d="M3 11L11 3M11 3H5M11 3V9"
                      stroke="currentColor"
                      strokeWidth="1.4"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </span>
              </div>
              <h3 className={styles.tileTitle}>{a.label}</h3>
              <p className={styles.tileDesc}>{a.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
