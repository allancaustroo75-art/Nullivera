import { principles } from "@/lib/data/services";
import styles from "./WhyNullivra.module.css";

export function WhyNullivra() {
  return (
    <section className={`section ${styles.section}`}>
      <div className={styles.bg} aria-hidden="true" />
      <div className="container">
        <div className={styles.inner}>
          <div className={styles.heading}>
            <div className={styles.eyebrow}>
              <span className={styles.dot} />
              <span>04 — Principle</span>
            </div>
            <h2 className={styles.title}>
              Why <span className={styles.italic}>Nullivra?</span>
            </h2>
            <p className={styles.lede}>
              We operate with the discipline of an institutional practice. Every
              case is structured, evidence-led and handled with the discretion
              your brand requires.
            </p>
            <div className={styles.statsRow}>
              <div className={styles.stat}>
                <span className={styles.statLabel}>Discipline</span>
                <span className={styles.statValue}>Institutional</span>
              </div>
              <div className={styles.stat}>
                <span className={styles.statLabel}>Method</span>
                <span className={styles.statValue}>Evidence-led</span>
              </div>
              <div className={styles.stat}>
                <span className={styles.statLabel}>Posture</span>
                <span className={styles.statValue}>Discreet</span>
              </div>
            </div>
          </div>

          <div className={styles.principles}>
            {principles.map((p, i) => (
              <div
                key={p.title}
                className={`${styles.principle} reveal reveal-delay-${(i % 6) + 1}`}
              >
                <div className={styles.principleTop}>
                  <span className={styles.principleIndex}>
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <h3 className={styles.principleTitle}>{p.title}</h3>
                </div>
                <p className={styles.principleDesc}>{p.description}</p>
                <span className={styles.principleLine} aria-hidden="true" />
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
