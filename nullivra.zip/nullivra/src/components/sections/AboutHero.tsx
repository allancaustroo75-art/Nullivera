import { EnquiryModalButton } from "@/components/ui/EnquiryModalButton";
import { Wordmark } from "@/components/ui/Wordmark";
import styles from "./AboutHero.module.css";

export function AboutHero() {
  return (
    <section className={styles.section}>
      <div className={styles.bg} aria-hidden="true" />
      <div className="container">
        <div className={styles.inner}>
          <div className={styles.eyebrow}>
            <Wordmark size="small" />
            <span className={styles.line} />
            <span>The Agency</span>
          </div>
          <h1 className={styles.title}>
            Digital Protection, Built as a{" "}
            <span className={styles.italic}>Real Company</span> — Not a
            Freelancer.
          </h1>
          <p className={styles.lede}>
            Nullivra is a digital brand protection and digital risk management
            agency. We work with brands, creators and businesses to identify,
            manage and respond to digital threats affecting their identity,
            reputation and intellectual property.
          </p>
          <p className={styles.lede2}>
            Our work is delivered through structured workflows, professional
            case management and a discipline drawn from the standards of an
            institutional practice — not a freelance marketplace, not a
            template takedown service, and not an automated tool.
          </p>
          <div className={styles.actions}>
            <EnquiryModalButton mode="consultation" variant="primary">
              Request a Consultation
              <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden="true">
                <path
                  d="M3 7H11M11 7L7 3M11 7L7 11"
                  stroke="currentColor"
                  strokeWidth="1.6"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </EnquiryModalButton>
          </div>
        </div>
      </div>
    </section>
  );
}
