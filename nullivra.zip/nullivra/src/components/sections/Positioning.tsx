import styles from "./Positioning.module.css";

export function Positioning() {
  return (
    <section id="positioning" className={styles.section}>
      <div className="container">
        <div className={styles.inner}>
          <div className={styles.heading}>
            <div className={styles.eyebrow}>
              <span className={styles.dot} />
              <span>01 — Position</span>
            </div>
            <h2 className={styles.title}>
              Digital trust is a{" "}
              <span className={styles.italic}>business asset.</span>
            </h2>
          </div>
          <div className={styles.body}>
            <p className={styles.text}>
              From impersonation and unauthorized content to emerging digital
              risks, Nullivra provides structured support for protecting what
              your brand has built online.
            </p>
            <div className={styles.markers}>
              <div className={styles.marker}>
                <span className={styles.markerIndex}>01</span>
                <span className={styles.markerLabel}>Identify</span>
              </div>
              <div className={styles.marker}>
                <span className={styles.markerIndex}>02</span>
                <span className={styles.markerLabel}>Structure</span>
              </div>
              <div className={styles.marker}>
                <span className={styles.markerIndex}>03</span>
                <span className={styles.markerLabel}>Respond</span>
              </div>
              <div className={styles.marker}>
                <span className={styles.markerIndex}>04</span>
                <span className={styles.markerLabel}>Monitor</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
