import { processSteps } from "@/lib/data/services";
import styles from "./Process.module.css";

export function Process() {
  return (
    <section id="process" className={`section ${styles.section}`}>
      <div className="container">
        <div className={styles.header}>
          <div className={styles.eyebrow}>
            <span className={styles.dot} />
            <span>03 — Method</span>
          </div>
          <h2 className={styles.title}>
            From Discovery <span className={styles.italic}>to Resolution.</span>
          </h2>
          <p className={styles.lede}>
            A defined four-step framework — the same professional structure we
            apply to every case, from initial intake to final reporting.
          </p>
        </div>

        <div className={styles.timeline}>
          <div className={styles.line} aria-hidden="true" />
          {processSteps.map((step, i) => (
            <div
              key={step.number}
              className={`${styles.step} reveal reveal-delay-${i + 1}`}
            >
              <div className={styles.stepMarker}>
                <span className={styles.stepNumber}>{step.number}</span>
                <span className={styles.stepDot} aria-hidden="true" />
              </div>
              <h3 className={styles.stepTitle}>{step.title}</h3>
              <p className={styles.stepDesc}>{step.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
