import styles from "./InsightsHero.module.css";

export function InsightsHero() {
  return (
    <section className={styles.section}>
      <div className={styles.bg} aria-hidden="true" />
      <div className="container">
        <div className={styles.inner}>
          <span className={styles.eyebrow}>
            <span className={styles.dot} />
            <span>Insights · Research · Field Notes</span>
          </span>
          <h1 className={styles.title}>
            Editorial perspective on the{" "}
            <span className={styles.italic}>modern digital surface.</span>
          </h1>
          <p className={styles.lede}>
            A growing library of structured analysis on brand protection,
            digital risk, impersonation, copyright and online identity —
            published as the practice evolves.
          </p>
        </div>
      </div>
    </section>
  );
}
