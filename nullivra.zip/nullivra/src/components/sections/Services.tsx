import { services } from "@/lib/data/services";
import { ServiceIcon, ArrowUpRight } from "@/components/ui/Icon";
import { EnquiryModalButton } from "@/components/ui/EnquiryModalButton";
import styles from "./Services.module.css";

export function Services() {
  return (
    <section id="services" className={`section ${styles.section}`}>
      <div className="container">
        <div className={styles.header}>
          <div className={styles.headerLeft}>
            <div className={styles.eyebrow}>
              <span className={styles.dot} />
              <span>02 — Capabilities</span>
            </div>
            <h2 className={styles.title}>
              Digital Protection,{" "}
              <span className={styles.italic}>Built Around Your Brand.</span>
            </h2>
          </div>
          <p className={styles.lede}>
            Six structured practice areas covering the modern surface of
            digital risk — delivered with the discipline of a professional
            services practice.
          </p>
        </div>

        <div className={styles.grid}>
          {services.map((service, i) => (
            <article
              key={service.id}
              className={`${styles.card} reveal reveal-delay-${(i % 6) + 1}`}
            >
              <div className={styles.cardTop}>
                <span className={styles.cardNumber}>{service.number}</span>
                <span className={styles.cardArrow} aria-hidden="true">
                  <ArrowUpRight size={14} />
                </span>
              </div>

              <div className={styles.cardIcon}>
                <ServiceIcon name={service.icon} size={24} />
              </div>

              <h3 className={styles.cardTitle}>{service.title}</h3>
              <p className={styles.cardDesc}>{service.description}</p>

              <div className={styles.cardFoot}>
                <span className={styles.cardLine} />
                <EnquiryModalButton
                  mode="case"
                  variant="link"
                  className={styles.cardLink}
                >
                  Discuss this →
                </EnquiryModalButton>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
