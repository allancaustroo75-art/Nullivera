import { EnquiryModalButton } from "@/components/ui/EnquiryModalButton";
import styles from "./CaseCta.module.css";

export function CaseCta() {
  return (
    <section className={`section ${styles.section}`}>
      <div className={styles.bg} aria-hidden="true" />
      <div className={styles.grid} aria-hidden="true" />

      <div className="container">
        <div className={styles.inner}>
          <div className={styles.copy}>
            <div className={styles.eyebrow}>
              <span className={styles.dot} />
              <span>06 — Engage</span>
            </div>
            <h2 className={styles.title}>
              Something online is{" "}
              <span className={styles.italic}>putting your brand at risk?</span>
            </h2>
            <p className={styles.lede}>
              Tell us what happened. Our team will review the situation and help
              identify the appropriate next steps.
            </p>

            <div className={styles.actions}>
              <EnquiryModalButton mode="case" variant="primary">
                Submit a Case
                <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden="true">
                  <path
                    d="M3 7H11M11 7L7 3M11 7L7 11"
                    stroke="currentColor"
                    strokeWidth="1.6"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </EnquiryModalButton>
              <EnquiryModalButton mode="consultation" variant="secondary">
                Request a Consultation
              </EnquiryModalButton>
            </div>

            <div className={styles.assurance}>
              <div className={styles.assuranceItem}>
                <span className={styles.assuranceDot} />
                <span>Confidential intake</span>
              </div>
              <div className={styles.assuranceItem}>
                <span className={styles.assuranceDot} />
                <span>Reviewed by a case lead</span>
              </div>
              <div className={styles.assuranceItem}>
                <span className={styles.assuranceDot} />
                <span>Discreet handling</span>
              </div>
            </div>
          </div>

          <div className={styles.card} aria-hidden="true">
            <div className={styles.cardHeader}>
              <span className={styles.cardTitle}>Case Intake</span>
              <span className={styles.cardStatus}>
                <span className={styles.cardPulse} />
                <span>Active</span>
              </span>
            </div>
            <div className={styles.cardFields}>
              <div className={styles.field}>
                <span className={styles.fieldLabel}>Brand</span>
                <span className={styles.fieldValue}>—</span>
              </div>
              <div className={styles.field}>
                <span className={styles.fieldLabel}>Surface</span>
                <span className={styles.fieldValue}>—</span>
              </div>
              <div className={styles.field}>
                <span className={styles.fieldLabel}>Risk</span>
                <span className={styles.fieldValue}>—</span>
              </div>
              <div className={styles.field}>
                <span className={styles.fieldLabel}>Status</span>
                <span className={styles.fieldValue}>
                  <span className={styles.statusDot} />
                  Awaiting intake
                </span>
              </div>
            </div>
            <div className={styles.cardFoot}>
              <span className={styles.footLine} />
              <span className={styles.footText}>Structured workflow</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
