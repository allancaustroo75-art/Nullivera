"use client";

import { ReactNode } from "react";
import { SessionProvider } from "next-auth/react";
import { EnquiryModalProvider } from "@/lib/hooks/useEnquiryModal";
import { useScrollReveal } from "@/lib/hooks/useScrollReveal";

function RevealInit({ children }: { children: ReactNode }) {
  useScrollReveal();
  return <>{children}</>;
}

export function Providers({ children }: { children: ReactNode }) {
  return (
    <SessionProvider>
      <EnquiryModalProvider>
        <RevealInit>{children}</RevealInit>
      </EnquiryModalProvider>
    </SessionProvider>
  );
}
