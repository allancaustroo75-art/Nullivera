import Link from "next/link";
import { Wordmark } from "@/components/ui/Wordmark";
import { FooterCta } from "./FooterCta";
import { navLinks } from "@/lib/data/services";
import styles from "./Footer.module.css";

export function Footer() {
  return (
    <footer className={styles.footer}>
      <div className={styles.container}>
        <div className={styles.top}>
          <div className={styles.brandCol}>
            <Wordmark size="large" />
            <p className={styles.tagline}>
              Digital Brand Protection &amp; Digital Risk Management.
            </p>
            <FooterCta mode="consultation" className={styles.cta}>
              Request a Consultation
              <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden="true">
                <path
                  d="M3 7H11M11 7L7 3M11 7L7 11"
                  stroke="currentColor"
                  strokeWidth="1.4"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </FooterCta>
          </div>

          <div className={styles.linksWrap}>
            <div className={styles.linksCol}>
              <h4 className={styles.colTitle}>Navigation</h4>
              <ul className={styles.linksList}>
                {navLinks.map((l) => (
                  <li key={l.href}>
                    <Link href={l.href} className={styles.link}>
                      {l.label}
                    </Link>
                  </li>
                ))}
                <li>
                  <FooterCta mode="case" variant="link" className={styles.link}>
                    Submit a Case
                  </FooterCta>
                </li>
              </ul>
            </div>

            <div className={styles.linksCol}>
              <h4 className={styles.colTitle}>Practice</h4>
              <ul className={styles.linksList}>
                <li className={styles.muted}>Brand Protection</li>
                <li className={styles.muted}>Copyright Enforcement</li>
                <li className={styles.muted}>Impersonation Response</li>
                <li className={styles.muted}>Digital Risk Intelligence</li>
                <li className={styles.muted}>Reputation Protection</li>
                <li className={styles.muted}>Content Protection</li>
              </ul>
            </div>

            <div className={styles.linksCol}>
              <h4 className={styles.colTitle}>Engage</h4>
              <ul className={styles.linksList}>
                <li>
                  <FooterCta mode="case" variant="link" className={styles.link}>
                    Submit a Case
                  </FooterCta>
                </li>
                <li>
                  <FooterCta mode="consultation" variant="link" className={styles.link}>
                    Request a Consultation
                  </FooterCta>
                </li>
                <li>
                  <Link href="/insights" className={styles.link}>
                    Insights
                  </Link>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div className={styles.divider} />

        <div className={styles.bottom}>
          <p className={styles.copyright}>
            © {new Date().getFullYear()} Nullivra. All rights reserved.
          </p>
          <p className={styles.legal}>
            Structured digital protection for brands, creators and businesses.
          </p>
        </div>
      </div>

      <div className={styles.glow} aria-hidden="true" />
    </footer>
  );
}
