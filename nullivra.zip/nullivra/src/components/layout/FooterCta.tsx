"use client";

import { useEnquiryModal } from "@/lib/hooks/useEnquiryModal";
import styles from "@/components/ui/EnquiryModalButton.module.css";

type Variant = "primary" | "secondary" | "link";

type Props = {
  mode: "case" | "consultation";
  variant?: Variant;
  className?: string;
  children: React.ReactNode;
};

export function FooterCta({
  mode,
  variant = "primary",
  className = "",
  children,
}: Props) {
  const { open } = useEnquiryModal();

  return (
    <button
      type="button"
      className={`${styles.btn} ${styles[variant]} ${className}`}
      onClick={() => open(mode)}
    >
      {children}
    </button>
  );
}
