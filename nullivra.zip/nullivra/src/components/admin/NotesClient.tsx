"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import styles from "./NotesClient.module.css";

type Note = {
  id: string;
  body: string;
  createdAt: Date | string;
  author: { name?: string | null; email?: string | null };
};

export function NotesClient({ caseId, initialNotes }: { caseId: string; initialNotes: Note[] }) {
  const router = useRouter();
  const [body, setBody] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [, startTransition] = useTransition();

  async function add() {
    if (!body.trim()) return;
    setError(null);
    setSaving(true);
    const res = await fetch(`/api/cases/${caseId}/notes`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ body }),
    });
    setSaving(false);
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setError(data.error || "Failed to add note");
      return;
    }
    setBody("");
    startTransition(() => router.refresh());
  }

  return (
    <section className={styles.notes}>
      <div className={styles.notesHead}>
        <h2 className={styles.sectionTitle}>Internal notes</h2>
        <span className={styles.notesHint}>Only visible to the Nullivra team.</span>
      </div>

      {initialNotes.length === 0 ? (
        <p className={styles.empty}>No notes yet.</p>
      ) : (
        <ul className={styles.list}>
          {initialNotes.map((n) => (
            <li key={n.id} className={styles.note}>
              <div className={styles.noteHead}>
                <span className={styles.noteAuthor}>
                  {n.author.name || n.author.email || "Team"}
                </span>
                <span className={styles.noteDate}>
                  {new Date(n.createdAt).toLocaleString("en", {
                    day: "2-digit", month: "short", year: "numeric",
                    hour: "2-digit", minute: "2-digit",
                  })}
                </span>
              </div>
              <div className={styles.noteBody}>{n.body}</div>
            </li>
          ))}
        </ul>
      )}

      <div className={styles.composer}>
        <textarea
          className={styles.input}
          placeholder="Add an internal note for the team…"
          value={body}
          onChange={(e) => setBody(e.target.value)}
          rows={3}
          disabled={saving}
        />
        {error && <div className={styles.error}>{error}</div>}
        <div className={styles.composerFoot}>
          <span className={styles.composerHint}>Internal — not visible to the client.</span>
          <button
            type="button"
            className={styles.addBtn}
            onClick={add}
            disabled={!body.trim() || saving}
          >
            {saving ? "Adding…" : "Add note"}
          </button>
        </div>
      </div>
    </section>
  );
}
