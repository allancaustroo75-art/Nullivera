"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import styles from "./CaseControls.module.css";

const STATUSES = [
  { value: "NEW", label: "New" },
  { value: "REVIEWING", label: "Reviewing" },
  { value: "CONTACTED", label: "Contacted" },
  { value: "IN_PROGRESS", label: "In Progress" },
  { value: "RESOLVED", label: "Resolved" },
  { value: "CLOSED", label: "Closed" },
] as const;

export function CaseControls({ caseId, initialStatus }: { caseId: string; initialStatus: string }) {
  const router = useRouter();
  const [status, setStatus] = useState(initialStatus);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [, startTransition] = useTransition();

  const dirty = status !== initialStatus;

  async function save() {
    setSaving(true);
    setMsg(null);
    const res = await fetch(`/api/cases/${caseId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    });
    setSaving(false);
    if (!res.ok) {
      setMsg("Failed to save");
      return;
    }
    setMsg("Saved");
    startTransition(() => router.refresh());
    setTimeout(() => setMsg(null), 2000);
  }

  return (
    <div className={styles.controls}>
      <div className={styles.controlGroup}>
        <span className={styles.controlLabel}>Status</span>
        <select
          className={styles.select}
          value={status}
          onChange={(e) => setStatus(e.target.value)}
        >
          {STATUSES.map((s) => (
            <option key={s.value} value={s.value}>
              {s.label}
            </option>
          ))}
        </select>
      </div>

      <div className={styles.controlActions}>
        {msg && <span className={styles.controlMsg}>{msg}</span>}
        <button
          type="button"
          className={styles.saveBtn}
          onClick={save}
          disabled={!dirty || saving}
        >
          {saving ? "Saving…" : "Update status"}
        </button>
      </div>
    </div>
  );
}
