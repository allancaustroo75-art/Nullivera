import styles from "./StatusPill.module.css";

const LABELS: Record<string, string> = {
  NEW: "New",
  REVIEWING: "Reviewing",
  CONTACTED: "Contacted",
  IN_PROGRESS: "In Progress",
  RESOLVED: "Resolved",
  CLOSED: "Closed",
};

const COLORS: Record<string, string> = {
  NEW: "#4a8eff",
  REVIEWING: "#a78bfa",
  CONTACTED: "#f5b042",
  IN_PROGRESS: "#38bdf8",
  RESOLVED: "#4ade80",
  CLOSED: "#6b7388",
};

export function StatusPill({ status }: { status: string }) {
  const color = COLORS[status] || "#6b7388";
  return (
    <span className={styles.pill} style={{ color, borderColor: `${color}55` }}>
      <span className={styles.dot} style={{ background: color, boxShadow: `0 0 6px ${color}80` }} />
      {LABELS[status] || status}
    </span>
  );
}
