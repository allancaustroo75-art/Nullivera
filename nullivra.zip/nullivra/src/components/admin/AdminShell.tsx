"use client";

import { ReactNode } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { signOut } from "next-auth/react";
import { Wordmark } from "@/components/ui/Wordmark";
import styles from "./AdminShell.module.css";

export function AdminShell({ user, children }: { user: { name?: string | null; email?: string | null }; children: ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();

  const navItems = [
    { href: "/admin", label: "Cases", icon: (
      <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
        <path d="M3 4h10M3 8h10M3 12h6" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/>
      </svg>
    )},
  ];

  return (
    <div className={styles.shell}>
      <header className={styles.topbar}>
        <div className={styles.topbarInner}>
          <Link href="/admin" className={styles.brand}>
            <Wordmark size="small" />
            <span className={styles.brandTag}>ADMIN</span>
          </Link>
          <nav className={styles.topnav}>
            {navItems.map((n) => {
              const active = pathname === n.href || (n.href !== "/admin" && pathname.startsWith(n.href));
              return (
                <Link
                  key={n.href}
                  href={n.href}
                  className={`${styles.topnavLink} ${active ? styles.topnavActive : ""}`}
                >
                  {n.label}
                </Link>
              );
            })}
          </nav>
          <div className={styles.topbarRight}>
            <Link href="/" className={styles.viewSite} target="_blank">
              View site ↗
            </Link>
            <span className={styles.user}>{user.name || user.email}</span>
            <button
              type="button"
              className={styles.signOut}
              onClick={() => signOut({ callbackUrl: "/admin/login" })}
              aria-label="Sign out"
            >
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                <path d="M6 3H3v10h3M10 11l3-3-3-3M13 8H6" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </button>
          </div>
        </div>
      </header>

      <main className={styles.main}>{children}</main>
    </div>
  );
}
