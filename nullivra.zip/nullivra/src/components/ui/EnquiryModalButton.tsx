"use client";

import { useEnquiryModal } from "@/lib/hooks/useEnquiryModal";
import styles from "./EnquiryModalButton.module.css";

type Variant = "primary" | "secondary" | "link";

type Props = {
  mode: "case" | "consultation";
  variant?: Variant;
  className?: string;
  children: React.ReactNode;
  fullWidth?: boolean;
};

export function EnquiryModalButton({
  mode,
  variant = "primary",
  className = "",
  children,
  fullWidth = false,
}: Props) {
  const { open } = useEnquiryModal();
  const label = mode === "case" ? "Submit a Case" : "Request a Consultation";

  return (
    <button
      type="button"
      className={`${styles.btn} ${styles[variant]} ${fullWidth ? styles.full : ""} ${className}`}
      onClick={() => open(mode)}
      aria-label={label}
    >
      {children}
    </button>
  );
}
