"use client";

import { useEffect, useRef, useState, FormEvent } from "react";
import { useEnquiryModal } from "@/lib/hooks/useEnquiryModal";
import { platformGroups, issueCategories, getPlatformTAT } from "@/lib/data/services";
import styles from "./EnquiryModal.module.css";

type FormData = {
  fullName: string;
  company: string;
  email: string;
  phone: string;
  country: string;
  url: string;
  platform: string;
  issueType: string;
  description: string;
  relevantUrls: string;
  consent: boolean;
  files: File[];
};

type Errors = Partial<Record<keyof FormData, string>>;

const initialData: FormData = {
  fullName: "",
  company: "",
  email: "",
  phone: "",
  country: "",
  url: "",
  platform: "",
  issueType: "",
  description: "",
  relevantUrls: "",
  consent: false,
  files: [],
};

export function EnquiryModal() {
  const { mode, close } = useEnquiryModal();
  const firstFieldRef = useRef<HTMLInputElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [data, setData] = useState<FormData>(initialData);
  const [errors, setErrors] = useState<Errors>({});
  const [status, setStatus] = useState<"idle" | "submitting" | "success">("idle");
  const [reference, setReference] = useState<string | null>(null);
  const [serverError, setServerError] = useState<string | null>(null);

  useEffect(() => {
    if (mode) document.body.style.overflow = "hidden";
    else document.body.style.overflow = "";
    return () => { document.body.style.overflow = ""; };
  }, [mode]);

  useEffect(() => {
    if (!mode) return;
    const handler = (e: KeyboardEvent) => { if (e.key === "Escape") close(); };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [mode, close]);

  useEffect(() => {
    if (mode && firstFieldRef.current) {
      const t = setTimeout(() => firstFieldRef.current?.focus(), 200);
      return () => clearTimeout(t);
    }
  }, [mode]);

  useEffect(() => {
    if (!mode) {
      const t = setTimeout(() => {
        setData(initialData);
        setErrors({});
        setStatus("idle");
        setReference(null);
        setServerError(null);
        if (fileInputRef.current) fileInputRef.current.value = "";
      }, 400);
      return () => clearTimeout(t);
    }
  }, [mode]);

  if (!mode) return null;

  const title = mode === "case" ? "Submit a Case" : "Request a Consultation";
  const subtitle = mode === "case"
    ? "Provide the details below. Our team will review the situation and identify the appropriate next steps."
    : "Tell us briefly about your brand and what you're trying to protect. A case lead will follow up.";

  function validate(): boolean {
    const e: Errors = {};
    if (!data.fullName.trim()) e.fullName = "Required";
    if (!data.email.trim()) e.email = "Required";
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) e.email = "Please enter a valid email";
    if (data.phone && !/^[+\d][\d\s\-()]{5,}$/.test(data.phone)) e.phone = "Please enter a valid phone number";
    if (!data.country.trim()) e.country = "Required";
    if (!data.platform) e.platform = "Please select a platform";
    if (!data.issueType) e.issueType = "Please select an issue type";
    if (!data.description.trim() || data.description.trim().length < 20) e.description = "Please provide at least 20 characters";
    if (!data.consent) e.consent = "Required to proceed";
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (!validate()) return;
    setStatus("submitting");
    setServerError(null);

    try {
      const fd = new FormData();
      Object.entries(data).forEach(([k, v]) => {
        if (k === "files") {
          (v as File[]).forEach((f) => fd.append("files", f));
        } else if (k === "consent") {
          fd.append("consent", v ? "true" : "false");
        } else if (k === "phone" || k === "platform") {
          fd.append(k, String(v || ""));
        } else {
          fd.append(k, String(v));
        }
      });

      const res = await fetch("/api/cases", { method: "POST", body: fd });
      const result = await res.json();
      if (!res.ok) {
        setServerError(result.error || "Submission failed. Please try again.");
        setStatus("idle");
        return;
      }
      setReference(result.reference || null);
      setStatus("success");
    } catch {
      setServerError("Network error. Please try again.");
      setStatus("idle");
    }
  }

  const update = <K extends keyof FormData>(k: K, v: FormData[K]) => {
    setData((d) => ({ ...d, [k]: v }));
    if (errors[k]) setErrors((er) => ({ ...er, [k]: undefined }));
  };

  const handleFiles = (e: React.ChangeEvent<HTMLInputElement>) => {
    const list = e.target.files;
    if (!list) return;
    const arr = Array.from(list).slice(0, 6);
    update("files", arr);
  };

  const removeFile = (i: number) => {
    update("files", data.files.filter((_, idx) => idx !== i));
  };

  return (
    <div
      className={styles.backdrop}
      onClick={(e) => { if (e.target === e.currentTarget) close(); }}
      role="presentation"
    >
      <div
        className={styles.dialog}
        role="dialog"
        aria-modal="true"
        aria-labelledby="enquiry-title"
      >
        <div className={styles.header}>
          <div className={styles.headerLeft}>
            <span className={styles.eyebrow}>
              <span className={styles.dot} />
              <span>Confidential Enquiry</span>
            </span>
            <h2 id="enquiry-title" className={styles.title}>{title}</h2>
            <p className={styles.subtitle}>{subtitle}</p>
          </div>
          <button type="button" className={styles.close} onClick={close} aria-label="Close">
            <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
              <path d="M4 4L14 14M14 4L4 14" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
            </svg>
          </button>
        </div>

        {status === "success" ? (
          <SuccessView onClose={close} reference={reference} />
        ) : (
          <form className={styles.form} onSubmit={handleSubmit} noValidate>
            {serverError && <div className={styles.serverError}>{serverError}</div>}

            <div className={styles.row}>
              <Field label="Full Name" required error={errors.fullName}>
                <input ref={firstFieldRef} type="text" className={styles.input} placeholder="Jordan Hayes"
                  value={data.fullName} onChange={(e) => update("fullName", e.target.value)} autoComplete="name"/>
              </Field>
              <Field label="Company / Brand Name">
                <input type="text" className={styles.input} placeholder="Acme Studios"
                  value={data.company} onChange={(e) => update("company", e.target.value)} autoComplete="organization"/>
              </Field>
            </div>

            <div className={styles.row}>
              <Field label="Business Email" required error={errors.email}>
                <input type="email" className={styles.input} placeholder="name@company.com"
                  value={data.email} onChange={(e) => update("email", e.target.value)} autoComplete="email"/>
              </Field>
              <Field label="Phone" hint="Optional — for urgent cases only" error={errors.phone}>
                <input type="tel" className={styles.input} placeholder="+1 555 0100"
                  value={data.phone} onChange={(e) => update("phone", e.target.value)} autoComplete="tel"/>
              </Field>
            </div>

            <div className={styles.row}>
              <Field label="Country" required error={errors.country}>
                <input type="text" className={styles.input} placeholder="United Kingdom"
                  value={data.country} onChange={(e) => update("country", e.target.value)} autoComplete="country-name"/>
              </Field>
              <Field label="Website / Profile URL" hint="Your primary brand surface (optional)">
                <input type="text" className={styles.input} placeholder="https://"
                  value={data.url} onChange={(e) => update("url", e.target.value)}/>
              </Field>
            </div>

            <Field label="Platform" required hint="Where is the issue happening?" error={errors.platform}>
              <div className={styles.selectWrap}>
                <select
                  className={styles.select}
                  value={data.platform}
                  onChange={(e) => update("platform", e.target.value)}
                >
                  <option value="">Select a platform</option>
                  {platformGroups.map((group) => (
                    <optgroup key={group.label} label={group.label}>
                      {group.platforms.map((p) => (
                        <option key={p.value} value={p.value}>{p.label}</option>
                      ))}
                    </optgroup>
                  ))}
                </select>
                <svg className={styles.selectArrow} width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden="true">
                  <path d="M3 5L7 9L11 5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              {data.platform && getPlatformTAT(data.platform) && (
                <div className={styles.tatBadge}>
                  <span className={styles.tatDot} />
                  <span className={styles.tatLabel}>Typical response:</span>
                  <span className={styles.tatValue}>{getPlatformTAT(data.platform)!.window}</span>
                  {getPlatformTAT(data.platform)!.note && (
                    <span className={styles.tatNote}>— {getPlatformTAT(data.platform)!.note}</span>
                  )}
                </div>
              )}
            </Field>

            <Field label="Type of Issue" required error={errors.issueType}>
              <div className={styles.selectWrap}>
                <select
                  className={styles.select}
                  value={data.issueType}
                  onChange={(e) => update("issueType", e.target.value)}
                >
                  <option value="">Select issue type</option>
                  {issueCategories.map((c) => (
                    <option key={c.value} value={c.value}>{c.label}</option>
                  ))}
                </select>
                <svg className={styles.selectArrow} width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden="true">
                  <path d="M3 5L7 9L11 5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
            </Field>

            <Field label="Description of the Issue" required hint="Include context, dates, the specific profile or content, and what you've already tried" error={errors.description}>
              <textarea className={styles.textarea} rows={5} placeholder="Describe the situation in your own words…"
                value={data.description} onChange={(e) => update("description", e.target.value)}/>
              <div className={styles.counter}>{data.description.length} characters</div>
            </Field>

            <Field label="Relevant URLs" hint="One per line — links to the impersonator, infringing content, fake listings, etc.">
              <textarea className={styles.textarea} rows={3} placeholder="https://instagram.com/fake-account&#10;https://example.com/listing"
                value={data.relevantUrls} onChange={(e) => update("relevantUrls", e.target.value)}/>
            </Field>

            <Field label="Additional Evidence / Files" hint="Up to 6 files — screenshots, invoices, images, PDFs (max 10MB each)">
              <label className={styles.fileDrop}>
                <input ref={fileInputRef} type="file" multiple accept="image/*,.pdf,.doc,.docx"
                  onChange={handleFiles} className={styles.fileInput}/>
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                  <path d="M12 16V4M12 4L7 9M12 4L17 9" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M4 16v3a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-3" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
                <span className={styles.fileText}>
                  <span className={styles.filePrimary}>Click to upload</span> or drag and drop
                </span>
                <span className={styles.fileHint}>
                  {data.files.length > 0 ? `${data.files.length} file${data.files.length > 1 ? "s" : ""} selected` : "PNG, JPG, PDF up to 10MB"}
                </span>
              </label>
              {data.files.length > 0 && (
                <ul className={styles.fileList}>
                  {data.files.map((f, i) => (
                    <li key={`${f.name}-${i}`} className={styles.fileItem}>
                      <span className={styles.fileName}>{f.name}</span>
                      <span className={styles.fileSize}>{(f.size / 1024).toFixed(0)} KB</span>
                      <button type="button" className={styles.fileRemove} onClick={() => removeFile(i)} aria-label={`Remove ${f.name}`}>
                        <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                          <path d="M2 2L10 10M10 2L2 10" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/>
                        </svg>
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </Field>

            <div className={styles.consentRow}>
              <label className={styles.checkbox}>
                <input type="checkbox" checked={data.consent} onChange={(e) => update("consent", e.target.checked)}/>
                <span className={styles.checkmark} aria-hidden="true"/>
                <span className={styles.consentText}>
                  I understand that the information provided will be handled confidentially and used only to evaluate and respond to my enquiry.
                </span>
              </label>
              {errors.consent && <span className={styles.errorText}>{errors.consent}</span>}
            </div>

            <div className={styles.actions}>
              <button type="button" className={styles.cancel} onClick={close} disabled={status === "submitting"}>Cancel</button>
              <button type="submit" className={styles.submit} disabled={status === "submitting"}>
                {status === "submitting" ? (
                  <><span className={styles.spinner} /><span>Submitting…</span></>
                ) : (
                  <><span>Submit Confidential Enquiry</span>
                    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden="true">
                      <path d="M3 7H11M11 7L7 3M11 7L7 11" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </>
                )}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}

function Field({ label, hint, error, required, children }: { label: string; hint?: string; error?: string; required?: boolean; children: React.ReactNode }) {
  return (
    <label className={styles.field}>
      <span className={styles.label}>{label}{required && <span className={styles.required}> *</span>}</span>
      {children}
      {hint && !error && <span className={styles.hint}>{hint}</span>}
      {error && <span className={styles.errorText}>{error}</span>}
    </label>
  );
}

function SuccessView({ onClose, reference }: { onClose: () => void; reference: string | null }) {
  return (
    <div className={styles.success}>
      <div className={styles.successIcon}>
        <svg width="32" height="32" viewBox="0 0 24 24" fill="none">
          <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="1.4"/>
          <path d="M8 12l3 3 5-6" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      </div>
      <h3 className={styles.successTitle}>Enquiry received</h3>
      {reference && (
        <p className={styles.successRef}>
          Reference: <span className={styles.successRefCode}>{reference}</span>
        </p>
      )}
      <p className={styles.successText}>
        Thank you. Your enquiry has been received. Our team will review the information and contact you regarding the next steps.
      </p>
      <div className={styles.successMeta}>
        <span className={styles.successMetaItem}>A confirmation will be sent to your email</span>
      </div>
      <button type="button" className={styles.successButton} onClick={onClose}>Close</button>
    </div>
  );
}
