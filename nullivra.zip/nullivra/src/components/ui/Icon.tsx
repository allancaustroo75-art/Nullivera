type IconProps = {
  size?: number;
  className?: string;
};

const baseProps = (size: number) => ({
  width: size,
  height: size,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 1.4,
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
});

export function ShieldIcon({ size = 22, className }: IconProps) {
  return (
    <svg {...baseProps(size)} className={className}>
      <path d="M12 2L4 5.5V11c0 4.5 3.2 8.7 8 10.5 4.8-1.8 8-6 8-10.5V5.5L12 2Z" />
      <path d="M9 12l2 2 4-4" opacity="0.6" />
    </svg>
  );
}

export function ScaleIcon({ size = 22, className }: IconProps) {
  return (
    <svg {...baseProps(size)} className={className}>
      <path d="M12 3v18M6 7h12" />
      <path d="M6 7L3 14c0 1.5 1.5 2.5 3 2.5s3-1 3-2.5L6 7Z" />
      <path d="M18 7l-3 7c0 1.5 1.5 2.5 3 2.5s3-1 3-2.5L18 7Z" />
    </svg>
  );
}

export function FingerprintIcon({ size = 22, className }: IconProps) {
  return (
    <svg {...baseProps(size)} className={className}>
      <path d="M5 12a7 7 0 0 1 14 0" />
      <path d="M8 12a4 4 0 0 1 8 0c0 2 0 4-1 6" />
      <path d="M12 12c0 2 0 4 1 6" />
      <path d="M4 16c0-2 0-4 1-6" />
      <path d="M19 10c.7 1.5 1 3 1 4.5 0 1.5-.3 3-1 4.5" />
      <path d="M9 21c.5-1.5 1-3 1-5" opacity="0.6" />
    </svg>
  );
}

export function RadarIcon({ size = 22, className }: IconProps) {
  return (
    <svg {...baseProps(size)} className={className}>
      <circle cx="12" cy="12" r="9" opacity="0.4" />
      <circle cx="12" cy="12" r="5" opacity="0.6" />
      <circle cx="12" cy="12" r="1.5" fill="currentColor" />
      <path d="M12 12L19 7" />
    </svg>
  );
}

export function CompassIcon({ size = 22, className }: IconProps) {
  return (
    <svg {...baseProps(size)} className={className}>
      <circle cx="12" cy="12" r="9" />
      <path d="M15 9l-2 5-5 2 2-5 5-2Z" />
    </svg>
  );
}

export function LockIcon({ size = 22, className }: IconProps) {
  return (
    <svg {...baseProps(size)} className={className}>
      <rect x="4.5" y="11" width="15" height="10" rx="1.5" />
      <path d="M8 11V8a4 4 0 0 1 8 0v3" />
      <circle cx="12" cy="16" r="1" fill="currentColor" opacity="0.7" />
    </svg>
  );
}

export function ArrowUpRight({ size = 14, className }: IconProps) {
  return (
    <svg {...baseProps(size)} className={className}>
      <path d="M7 17L17 7M17 7H9M17 7V15" />
    </svg>
  );
}

const iconMap = {
  shield: ShieldIcon,
  scale: ScaleIcon,
  fingerprint: FingerprintIcon,
  radar: RadarIcon,
  compass: CompassIcon,
  lock: LockIcon,
};

export function ServiceIcon({
  name,
  size = 22,
  className,
}: IconProps & { name: string }) {
  const Icon = iconMap[name as keyof typeof iconMap];
  if (!Icon) return null;
  return <Icon size={size} className={className} />;
}
