import styles from "./Wordmark.module.css";

export function Wordmark({ size = "default" }: { size?: "default" | "small" | "large" }) {
  return (
    <span className={`${styles.wordmark} ${styles[size]}`} aria-label="Nullivra — Digital Brand Protection">
      <img
        src="/nullivra-logo.jpg"
        alt=""
        className={styles.logo}
        aria-hidden="true"
      />
    </span>
  );
}
