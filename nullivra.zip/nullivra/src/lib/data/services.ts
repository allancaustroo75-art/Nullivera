// Content data — kept separate from UI components for easy
// future integration with a CMS, database or API.

export type Service = {
  id: string;
  number: string;
  title: string;
  description: string;
  icon: string;
};

export const services: Service[] = [
  {
    id: "brand-protection",
    number: "01",
    title: "Brand Protection",
    description:
      "Identifying and addressing impersonation, fake accounts and brand abuse on Instagram, TikTok, X, LinkedIn, Amazon, eBay and across the wider web.",
    icon: "shield",
  },
  {
    id: "copyright-enforcement",
    number: "02",
    title: "Copyright Enforcement",
    description:
      "Structured support for removing unauthorized use of your photos, videos, music and written content on YouTube, TikTok, stock photo sites, blogs and marketplaces.",
    icon: "scale",
  },
  {
    id: "impersonation-response",
    number: "03",
    title: "Impersonation Response",
    description:
      "Identifying and reporting fake profiles, fraudulent handles and deceptive digital identities on Instagram, Facebook, LinkedIn, X, TikTok and Telegram.",
    icon: "fingerprint",
  },
  {
    id: "digital-risk-intelligence",
    number: "04",
    title: "Digital Risk Intelligence",
    description:
      "Mapping your exposure across social platforms, marketplaces, the open web and dark corners of the internet to surface risks before they escalate.",
    icon: "radar",
  },
  {
    id: "online-reputation-protection",
    number: "05",
    title: "Online Reputation Protection",
    description:
      "Responding to harmful reviews, defamatory posts, misleading search results and coordinated attacks across the platforms where your brand appears.",
    icon: "compass",
  },
  {
    id: "content-protection",
    number: "06",
    title: "Content Protection",
    description:
      "Monitoring and addressing unauthorized distribution, reproduction or misuse of your digital assets on YouTube, TikTok, Twitch, stock libraries and content farms.",
    icon: "lock",
  },
];

export type ProcessStep = {
  number: string;
  title: string;
  description: string;
};

export const processSteps: ProcessStep[] = [
  {
    number: "01",
    title: "Identify",
    description: "We understand the issue and assess the available information.",
  },
  {
    number: "02",
    title: "Verify",
    description:
      "We review the relevant digital presence, content and supporting evidence.",
  },
  {
    number: "03",
    title: "Act",
    description: "We use the appropriate reporting or enforcement pathway.",
  },
  {
    number: "04",
    title: "Monitor",
    description:
      "Where applicable, we help track the issue and identify recurring risks.",
  },
];

export type Principle = {
  title: string;
  description: string;
};

export const principles: Principle[] = [
  {
    title: "Structured workflows",
    description:
      "Every case follows a defined process — no improvisation, no shortcuts.",
  },
  {
    title: "Evidence-focused approach",
    description:
      "Decisions are grounded in verifiable information, not assumptions.",
  },
  {
    title: "Professional case handling",
    description:
      "Cases are managed with the discipline of an institutional practice.",
  },
  {
    title: "Clear communication",
    description:
      "Concise updates, defined milestones and zero ambiguity throughout.",
  },
  {
    title: "Scalable protection",
    description:
      "Built for growing brands whose digital footprint is constantly expanding.",
  },
  {
    title: "Global digital focus",
    description:
      "Operates across platforms, regions and the modern digital surface.",
  },
];

export type Audience = {
  label: string;
  description: string;
};

export const audiences: Audience[] = [
  { label: "Creators", description: "Independent voices with growing reach" },
  { label: "Founders", description: "Operators building reputation and equity" },
  { label: "Businesses", description: "Companies managing complex digital presence" },
  { label: "Public Figures", description: "Individuals with high public visibility" },
  { label: "Digital Brands", description: "Modern brands operating natively online" },
  { label: "Online Communities", description: "Groups whose identity lives online" },
];

export type IssueType = {
  value: string;
  label: string;
  group?: string;
};

export type PlatformGroup = {
  label: string;
  platforms: IssueType[];
};

// Specific platforms people encounter impersonation / infringement on
export const platformGroups: PlatformGroup[] = [
  {
    label: "Social platforms",
    platforms: [
      { value: "instagram", label: "Instagram", group: "social" },
      { value: "tiktok", label: "TikTok", group: "social" },
      { value: "x-twitter", label: "X (Twitter)", group: "social" },
      { value: "facebook", label: "Facebook", group: "social" },
      { value: "linkedin", label: "LinkedIn", group: "social" },
      { value: "youtube", label: "YouTube", group: "social" },
      { value: "snapchat", label: "Snapchat", group: "social" },
      { value: "reddit", label: "Reddit", group: "social" },
      { value: "threads", label: "Threads", group: "social" },
      { value: "pinterest", label: "Pinterest", group: "social" },
    ],
  },
  {
    label: "Marketplaces & commerce",
    platforms: [
      { value: "amazon", label: "Amazon", group: "marketplace" },
      { value: "ebay", label: "eBay", group: "marketplace" },
      { value: "etsy", label: "Etsy", group: "marketplace" },
      { value: "aliexpress", label: "AliExpress", group: "marketplace" },
      { value: "shopify", label: "Shopify (independent store)", group: "marketplace" },
      { value: "temu", label: "Temu", group: "marketplace" },
    ],
  },
  {
    label: "Content & creator",
    platforms: [
      { value: "youtube-creator", label: "YouTube (channel/creator)", group: "content" },
      { value: "twitch", label: "Twitch", group: "content" },
      { value: "patreon", label: "Patreon", group: "content" },
      { value: "substack", label: "Substack", group: "content" },
      { value: "medium", label: "Medium", group: "content" },
      { value: "wordpress", label: "WordPress / blog", group: "content" },
    ],
  },
  {
    label: "Domain & web",
    platforms: [
      { value: "fake-website", label: "Fake / clone website", group: "web" },
      { value: "domain-squatted", label: "Domain squatting", group: "web" },
      { value: "search-results", label: "Search engine results", group: "web" },
      { value: "app-store", label: "App Store / Play Store", group: "web" },
    ],
  },
  {
    label: "Messaging & communication",
    platforms: [
      { value: "whatsapp", label: "WhatsApp", group: "messaging" },
      { value: "telegram", label: "Telegram", group: "messaging" },
      { value: "discord", label: "Discord", group: "messaging" },
      { value: "email-spoofing", label: "Email / domain spoofing", group: "messaging" },
      { value: "sms", label: "SMS / text message", group: "messaging" },
    ],
  },
  {
    label: "Other",
    platforms: [
      { value: "multiple", label: "Multiple platforms", group: "other" },
      { value: "not-sure", label: "Not sure yet", group: "other" },
    ],
  },
];

/**
 * Typical initial review time per platform.
 * These are typical windows for the *first response / first review* —
 * NOT guarantees of resolution. Actual time depends on case complexity,
 * evidence quality, platform response, and whether escalation is needed.
 *
 * Only platforms with a confirmed, well-defined response window are
 * listed. Platforms without a stable internal pipeline (e.g. independent
 * Shopify stores, self-hosted WordPress, multi-surface cases) are not
 * given a fixed window — they are handled on a per-case basis.
 */
export const platformTAT: Record<string, { window: string; note?: string }> = {
  "x-twitter": { window: "Same day" },
  reddit: { window: "Same day" },
  youtube: { window: "1 – 5 days" },
  tiktok: { window: "2 – 5 days" },
  instagram: { window: "3 – 14 days" },
  facebook: { window: "3 – 14 days" },
};

export function getPlatformTAT(slug: string | null): { window: string; note?: string } | null {
  if (!slug) return null;
  return platformTAT[slug] || null;
}

// Legacy flat list (kept for backwards compatibility / admin display)
export const issueTypes: IssueType[] = [
  { value: "brand-impersonation", label: "Brand Impersonation" },
  { value: "copyright-infringement", label: "Copyright Infringement" },
  { value: "fake-account", label: "Fake Account" },
  { value: "unauthorized-content", label: "Unauthorized Content" },
  { value: "digital-identity-misuse", label: "Digital Identity Misuse" },
  { value: "other", label: "Other" },
];

// Type of issue — separate from platform
export const issueCategories: IssueType[] = [
  { value: "impersonation", label: "Impersonation of me / my brand" },
  { value: "fake-account", label: "Fake account using my identity" },
  { value: "copyright", label: "Copyright / content infringement" },
  { value: "counterfeit", label: "Counterfeit goods being sold" },
  { value: "unauthorized-use", label: "Unauthorized use of my content" },
  { value: "reputation", label: "Reputation / defamation issue" },
  { value: "data-leak", label: "Data leak / exposed information" },
  { value: "other", label: "Other digital risk" },
];

export const navLinks = [
  { href: "/", label: "Home" },
  { href: "/#services", label: "Services" },
  { href: "/#process", label: "How It Works" },
  { href: "/about", label: "About" },
  { href: "/insights", label: "Insights" },
];

export type InsightCategory = {
  slug: string;
  label: string;
};

export const insightCategories: InsightCategory[] = [
  { slug: "brand-protection", label: "Brand Protection" },
  { slug: "digital-risk", label: "Digital Risk" },
  { slug: "impersonation", label: "Impersonation" },
  { slug: "copyright", label: "Copyright" },
  { slug: "online-identity", label: "Online Identity" },
  { slug: "platform-updates", label: "Platform Updates" },
];

export type InsightArticle = {
  slug: string;
  category: string;
  title: string;
  excerpt: string;
  readTime: string;
  date: string;
  featured?: boolean;
};

export const insightArticles: InsightArticle[] = [
  {
    slug: "modern-brand-impersonation",
    category: "brand-protection",
    title: "The Modern Shape of Brand Impersonation",
    excerpt:
      "How fraudulent identities have moved beyond simple copycat accounts into orchestrated, multi-surface operations.",
    readTime: "—",
    date: "—",
    featured: true,
  },
  {
    slug: "copyright-platform-evolution",
    category: "copyright",
    title: "Copyright Enforcement in the Platform Era",
    excerpt:
      "An editorial look at how enforcement pathways have fragmented across platforms and what structured response now requires.",
    readTime: "—",
    date: "—",
  },
  {
    slug: "digital-risk-creators",
    category: "digital-risk",
    title: "Digital Risk for Independent Creators",
    excerpt:
      "The expanding risk surface faced by creators operating as full-stack personal brands.",
    readTime: "—",
    date: "—",
  },
  {
    slug: "fake-account-signals",
    category: "impersonation",
    title: "Reading the Signals of a Fake Account",
    excerpt:
      "Subtle indicators that distinguish a casual impersonator from a deliberate identity operation.",
    readTime: "—",
    date: "—",
  },
  {
    slug: "online-identity-as-asset",
    category: "online-identity",
    title: "Online Identity as a Protected Asset",
    excerpt:
      "Why digital identity now sits alongside trademarks and intellectual property in the modern risk register.",
    readTime: "—",
    date: "—",
  },
  {
    slug: "platform-reporting-channels",
    category: "platform-updates",
    title: "Navigating Modern Platform Reporting Channels",
    excerpt:
      "A practical map of the reporting pathways used across the major digital surfaces today.",
    readTime: "—",
    date: "—",
  },
];
