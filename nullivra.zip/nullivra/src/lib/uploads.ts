import { put, del } from "@vercel/blob";
import path from "path";
import crypto from "crypto";

// Files are stored in Vercel Blob (cloud object storage) instead of the
// local filesystem, since serverless hosting (Vercel/Netlify) has an
// ephemeral filesystem — anything written to disk can disappear on the
// next deploy or cold start.
//
// Requires BLOB_READ_WRITE_TOKEN in the environment. On Vercel, this is
// set automatically once you create a Blob store and connect it to the
// project (Storage tab in the dashboard). For local dev, run
// `vercel env pull` after creating the store, or set it manually in .env.

const MAX_BYTES = (parseInt(process.env.MAX_UPLOAD_MB || "10", 10)) * 1024 * 1024;

const ALLOWED_MIME = [
  "image/jpeg",
  "image/png",
  "image/webp",
  "image/gif",
  "application/pdf",
  "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
];

export type SavedFile = {
  storedAs: string; // Blob URL — used to fetch/delete the file later
  filename: string;
  mimeType: string;
  size: number;
};

export async function saveFile(file: File): Promise<SavedFile> {
  if (file.size > MAX_BYTES) {
    throw new Error(`File too large. Max ${MAX_BYTES / 1024 / 1024}MB`);
  }
  if (!ALLOWED_MIME.includes(file.type)) {
    throw new Error(`File type not allowed: ${file.type}`);
  }

  const now = new Date();
  const subdir = `${now.getFullYear()}/${String(now.getMonth() + 1).padStart(2, "0")}`;
  const ext = path.extname(file.name).slice(0, 10) || "";
  const key = `${subdir}/${crypto.randomUUID()}${ext}`;

  const blob = await put(key, file, {
    access: "public",
    contentType: file.type,
    addRandomSuffix: false,
  });

  return {
    storedAs: blob.url,
    filename: file.name,
    mimeType: file.type,
    size: file.size,
  };
}

export async function deleteFile(storedAs: string): Promise<void> {
  await del(storedAs);
}
