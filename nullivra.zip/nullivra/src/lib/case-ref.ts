import { prisma } from "./prisma";

export async function generateCaseReference(): Promise<string> {
  const year = new Date().getFullYear();
  const prefix = `NV-${year}-`;

  const lastCase = await prisma.case.findFirst({
    where: { reference: { startsWith: prefix } },
    orderBy: { reference: "desc" },
    select: { reference: true },
  });

  let nextNum = 1;
  if (lastCase) {
    const lastNum = parseInt(lastCase.reference.replace(prefix, ""), 10);
    if (!isNaN(lastNum)) nextNum = lastNum + 1;
  }

  return `${prefix}${String(nextNum).padStart(4, "0")}`;
}
