"use client";

import { useEffect } from "react";

/**
 * Observes elements with the `.reveal` class and adds `is-visible` when in view.
 * Respects prefers-reduced-motion (CSS already handles it).
 *
 * Strategy: by default, .reveal elements are VISIBLE (graceful no-JS).
 * On mount, we add `.reveal-ready` to the document which causes
 * .reveal:not(.is-visible) to fade to opacity 0 via CSS. Then the
 * IntersectionObserver adds .is-visible to bring them back in.
 *
 * The rootMargin is large so elements far below the fold are revealed
 * proactively when the page is at the top.
 */
export function useScrollReveal() {
  useEffect(() => {
    if (typeof window === "undefined") return;

    const reduced = window.matchMedia(
      "(prefers-reduced-motion: reduce)"
    ).matches;

    const elements = document.querySelectorAll<HTMLElement>(".reveal");

    if (reduced) {
      elements.forEach((el) => el.classList.add("is-visible"));
      return;
    }

    if (!("IntersectionObserver" in window)) {
      elements.forEach((el) => el.classList.add("is-visible"));
      return;
    }

    document.documentElement.classList.add("reveal-ready");

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            observer.unobserve(entry.target);
          }
        });
      },
      {
        threshold: 0,
        rootMargin: "0px 0px 2000px 0px",
      }
    );

    elements.forEach((el) => observer.observe(el));

    const timeout = window.setTimeout(() => {
      elements.forEach((el) => el.classList.add("is-visible"));
    }, 800);

    return () => {
      observer.disconnect();
      window.clearTimeout(timeout);
      document.documentElement.classList.remove("reveal-ready");
    };
  }, []);
}
