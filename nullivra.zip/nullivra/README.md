# Nullivra

**Digital Brand Protection & Digital Risk Management.**

A premium enterprise-grade marketing site for Nullivra, with a fully functional internal admin panel for case management.

- Public site — premium editorial frontend, enquiry form, About, Insights
- Admin panel — case list, status workflow, internal notes, file downloads, activity log
- Backend — Next.js API routes + Prisma + PostgreSQL
- Auth — NextAuth (Credentials, JWT, bcrypt)

---

## Stack

- **Framework:** Next.js 14 (App Router) + TypeScript
- **Database:** PostgreSQL (Neon / Supabase / Railway / RDS / local)
- **ORM:** Prisma 6
- **Auth:** NextAuth 4 (Credentials provider, JWT sessions, bcryptjs hashing)
- **Validation:** Zod
- **Styling:** CSS Modules (no Tailwind, no UI library)
- **Fonts:** Inter, Instrument Serif (italic display), JetBrains Mono — via `next/font/google`

---

## Quick start

### 1. Prerequisites

- Node.js 18+ and npm
- A running PostgreSQL instance (any of):
  - **Neon** (free tier): https://neon.tech
  - **Supabase** (free tier): https://supabase.com
  - **Railway** (free tier): https://railway.app
  - Local Postgres via Docker: `docker run -d -p 5432:5432 -e POSTGRES_PASSWORD=postgres postgres:16`
  - Local Postgres install (apt/brew/etc.)

### 2. Configure environment

```bash
cp .env.example .env
```

Edit `.env` and set `DATABASE_URL` to your Postgres connection string:

```env
DATABASE_URL="postgresql://USER:PASSWORD@HOST:5432/DBNAME?schema=public"
NEXTAUTH_URL="http://localhost:3000"
NEXTAUTH_SECRET="$(openssl rand -base64 32)"
UPLOAD_DIR="./uploads"
MAX_UPLOAD_MB="10"
APP_URL="http://localhost:3000"
```

**Important:** the database user must have permission to `CREATE DATABASE` (for Prisma's shadow database during `migrate dev`). On Neon/Supabase this is the default. On a hardened local Postgres, run once:

```sql
ALTER USER myuser CREATEDB;
```

### 3. Install + migrate + seed

```bash
npm install
npx prisma migrate dev --name init
npx tsx prisma/seed.ts
```

The seed creates the default admin:

- Email: `admin@nullivra.com`
- Password: `Admin123!Change`

**Change the password immediately after first login.**

### 4. Run

```bash
npm run dev
```

Open:
- Public site: http://localhost:3000
- Admin login: http://localhost:3000/admin/login

---

## Project structure

```
nullivra/
├── prisma/
│   ├── schema.prisma          # PostgreSQL schema
│   ├── seed.ts                # Default admin seeder
│   └── migrations/            # Prisma migration history
├── public/
│   └── nullivra-logo.jpg      # Brand wordmark image
├── src/
│   ├── app/
│   │   ├── (public)/          # Public site (route group)
│   │   │   ├── page.tsx       # Home
│   │   │   ├── about/         # About page
│   │   │   └── insights/      # Insights page
│   │   ├── admin/
│   │   │   ├── login/         # Login page (outside admin shell)
│   │   │   └── (dashboard)/   # Protected admin (route group)
│   │   │       ├── page.tsx           # Case list
│   │   │       └── cases/[id]/        # Case detail
│   │   └── api/
│   │       ├── auth/[...nextauth]/    # NextAuth
│   │       ├── cases/                 # POST public, PATCH admin
│   │       ├── cases/[id]/notes/      # POST admin
│   │       └── files/[id]/            # GET admin (download)
│   ├── components/
│   │   ├── sections/          # Hero, Services, Process, Why, Audiences, ResponseTimes…
│   │   ├── admin/             # AdminShell, CaseControls, NotesClient, StatusPill
│   │   ├── layout/            # Navbar, Footer, FooterCta
│   │   ├── ui/                # Wordmark, EnquiryModal, EnquiryModalButton, Icon
│   │   └── hero-visual/       # Canvas network animation
│   ├── lib/
│   │   ├── auth.ts            # NextAuth config
│   │   ├── prisma.ts          # Prisma client singleton
│   │   ├── session.ts         # requireAdmin server helper
│   │   ├── uploads.ts         # File upload handling
│   │   ├── hooks/             # useEnquiryModal, useScrollReveal
│   │   └── data/services.ts   # Services, principles, process, audiences, platformTAT
│   └── types/
│       └── next-auth.d.ts     # Session type augmentation
└── .env / .env.example
```

---

## Switching providers (e.g. back to SQLite for local prototyping)

1. Edit `prisma/schema.prisma`:
   ```prisma
   datasource db {
     provider = "sqlite"
     url      = env("DATABASE_URL")
   }
   ```
2. Edit `.env`:
   ```env
   DATABASE_URL="file:./dev.db"
   ```
3. Reset:
   ```bash
   npx prisma migrate reset --force
   npx tsx prisma/seed.ts
   ```

---

## Useful scripts

```bash
npm run dev           # Start dev server (HMR, port 3000)
npm run build         # Production build
npm run start         # Run production build
npm run db:generate   # Regenerate Prisma client
npm run db:migrate    # Run migrations (dev)
npm run db:reset      # Drop + recreate database
npm run db:seed       # Seed default admin
```

---

## Production notes

- Set a real `NEXTAUTH_SECRET` (`openssl rand -base64 32`)
- Set `NEXTAUTH_URL` to your real domain
- Use a managed Postgres (Neon/Supabase/RDS) for reliability
- Configure Postgres backups
- Behind a reverse proxy, set trust proxy headers if your app reads them
- Uploaded files are stored on local disk (`UPLOAD_DIR`) — for production scale, swap `src/lib/uploads.ts` to push to S3/R2

---

## License

Proprietary — Nullivra.
